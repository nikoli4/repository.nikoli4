# Build the AKL Revival Managed Windows Helper.
# Run with: powershell -ExecutionPolicy Bypass -File .\build-helper.ps1

$ErrorActionPreference = "Stop"

$Repo = $PSScriptRoot
$Source = Join-Path $Repo "resources\lib\managed_windows_helper.py"
$Bundled = Join-Path $Repo "resources\bin\AKLManagedHelper"
$Icon = Join-Path $Bundled "akl-revival-tray.ico"

$BuildRoot = Join-Path $Repo "build"
$Dist = Join-Path $BuildRoot "dist"
$Work = Join-Path $BuildRoot "work"
$Spec = Join-Path $BuildRoot "spec"
$Output = Join-Path $Dist "AKLManagedHelper"
$Zip = Join-Path $BuildRoot "AKLManagedHelper.zip"

if (-not (Test-Path $Source)) {
    throw "Helper source not found: $Source"
}

if (-not (Test-Path $Icon)) {
    throw "Tray icon not found: $Icon"
}

New-Item -ItemType Directory -Path $BuildRoot -Force | Out-Null

Push-Location $Repo

try {
    Write-Host "`n=== VERIFY PYTHON SOURCE ===" -ForegroundColor Cyan

    python -m py_compile $Source

    if ($LASTEXITCODE -ne 0) {
        throw "Python syntax validation failed."
    }

    Write-Host "`n=== VERIFY PYINSTALLER ===" -ForegroundColor Cyan

    python -m PyInstaller --version

    if ($LASTEXITCODE -ne 0) {
        throw "PyInstaller is unavailable."
    }

    Write-Host "`n=== BUILD HELPER ===" -ForegroundColor Cyan

    python -m PyInstaller `
        --noconfirm `
        --clean `
        --onedir `
        --windowed `
        --name AKLManagedHelper `
        --distpath $Dist `
        --workpath $Work `
        --specpath $Spec `
        $Source

    if ($LASTEXITCODE -ne 0) {
        throw "PyInstaller build failed."
    }

    Write-Host "`n=== VERIFY BUILD ===" -ForegroundColor Cyan

    $Exe = Join-Path $Output "AKLManagedHelper.exe"
    $Internal = Join-Path $Output "_internal"

    if (-not (Test-Path $Exe)) {
        throw "Built executable is missing."
    }

    if (-not (Test-Path $Internal -PathType Container)) {
        throw "PyInstaller internal directory is missing."
    }

    Copy-Item $Icon (Join-Path $Output "akl-revival-tray.ico") -Force

    Write-Host "`n=== CREATE ZIP ===" -ForegroundColor Cyan

    if (Test-Path $Zip) {
        Remove-Item $Zip -Force
    }

    Compress-Archive -Path $Output -DestinationPath $Zip

    Write-Host "`n=== BUILD RESULTS ===" -ForegroundColor Green

    Get-Item $Exe, $Zip |
        Select-Object FullName, Length, LastWriteTime

    Write-Host "`n=== EXECUTABLE SHA256 ===" -ForegroundColor Cyan
    Get-FileHash $Exe -Algorithm SHA256
}
finally {
    Pop-Location
}