## 0.1.4

- Improved Kodi shutdown reliability with a verified force-close fallback when graceful shutdown times out.
- Added persistent emulator diagnostic logging for troubleshooting managed launches.
- Added a reproducible PowerShell build script for the bundled Windows helper.
- Updated the bundled Windows helper to the tested logging-enabled build.

## 0.1.3

- Updated the bundled Windows helper to a verified console-free build.
- Updated the Managed Windows Launcher release version.

## 0.1.2

- Added managed launching of Steam games and Steam shortcuts.
- Added support for resolving ordinary Windows shortcuts.
- Improved managed launch configuration and working-directory handling.
- Improved Steam launch monitoring and recovery behavior.

## AKL Revival 0.1.1

- Added the option to return Kodi to the last-viewed AKL collection after exiting a managed game.
- Improved Managed Windows Launcher exit and return-to-Kodi behavior.
- Updated launcher settings and English language labels.

## AKL Revival 0.1.0

- Initial AKL Revival Managed Windows Launcher release.
