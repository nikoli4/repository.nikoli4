## AKL Revival 0.1.1

- Added the option to return Kodi to the last-viewed AKL collection after exiting a managed game.
- Improved Managed Windows Launcher exit and return-to-Kodi behavior.
- Updated launcher settings and English language labels.

## AKL Revival 0.1.0

- Initial AKL Revival Managed Windows Launcher release.
