# -*- coding: utf-8 -*-
#
# Optional Managed Windows Launcher for AKL Revival
# Windows-only managed emulator launching
#
# --- Python standard library ---
from __future__ import unicode_literals
from __future__ import division

import sys
import logging

# --- Kodi stuff ---
import xbmcaddon

# AKL main imports
from akl import constants, settings, addons
from akl.utils import kodilogging, io, kodi

from akl.launchers import ExecutionSettings, get_executor_factory

# Local modules
from resources.lib.launcher import AppLauncher

kodilogging.config()
logger = logging.getLogger(__name__)

# --- Addon object (used to access settings) ---
addon = xbmcaddon.Addon()
addon_id = addon.getAddonInfo('id')
addon_version = addon.getAddonInfo('version')


# ---------------------------------------------------------------------------------------------
# This is the plugin entry point.
# ---------------------------------------------------------------------------------------------
def run_plugin():
    os_name = io.is_which_os()

    # --- Some debug stuff for development ---
    logger.info('------------ Called Advanced Kodi Launcher Plugin: Default plugins ------------')
    logger.info(f'addon.id         "{addon_id}"')
    logger.info(f'addon.version    "{addon_version}"')
    logger.info(f'sys.platform     "{sys.platform}"')
    logger.info(f'OS               "{os_name}"')

    for i in range(len(sys.argv)):
        logger.info('sys.argv[{}] "{}"'.format(i, sys.argv[i]))

    addon_args = addons.AklAddonArguments('script.akl.managedlauncher')
    try:
        addon_args.parse()
    except Exception as ex:
        logger.error('Exception in plugin', exc_info=ex)
        kodi.dialog_OK(text=addon_args.get_usage())
        return

    if addon_args.get_command() == addons.AklAddonArguments.LAUNCH:
        launch_rom(addon_args)
    elif addon_args.get_command() == addons.AklAddonArguments.CONFIGURE_LAUNCHER:
        configure_launcher(addon_args)
    elif addon_args.args.cmd == "update-settings":
        # Capabilities are statically declared in resources/settings.xml.
        logger.info("Managed launcher settings are already defined.")
    else:
        kodi.dialog_OK(text=addon_args.get_help())

    logger.debug('Advanced Kodi Launcher Plugin: Default plugins -> exit')


# ---------------------------------------------------------------------------------------------
# Launcher methods.
# ---------------------------------------------------------------------------------------------
# Arguments: --akl_addon_id --rom_id
def launch_rom(args: addons.AklAddonArguments):
    logger.debug('App Launcher: Starting ...')

    try:
        execution_settings = ExecutionSettings()
        execution_settings.delay_tempo = settings.getSettingAsInt('delay_tempo')
        execution_settings.display_launcher_notify = settings.getSettingAsBool('display_launcher_notify')
        execution_settings.is_non_blocking = settings.getSettingAsBool('is_non_blocking')
        execution_settings.media_state_action = settings.getSettingAsInt('media_state_action')
        execution_settings.suspend_audio_engine = settings.getSettingAsBool('suspend_audio_engine')
        execution_settings.suspend_screensaver = settings.getSettingAsBool('suspend_screensaver')
        execution_settings.suspend_joystick_engine = settings.getSettingAsBool('suspend_joystick')

        addon_dir = kodi.getAddonDir()
        report_path = addon_dir.pjoin('reports')
        if not report_path.exists():
            report_path.makedirs()
        report_path = report_path.pjoin('{}-{}.txt'.format(args.get_akl_addon_id(), args.get_entity_id()))

        executor_factory = get_executor_factory(report_path)
        launcher = AppLauncher(
            args.get_akl_addon_id(),
            args.get_entity_id(),
            args.get_webserver_host(),
            args.get_webserver_port(),
            executorFactory=executor_factory,
            execution_settings=execution_settings,
            entity_type=args.get_entity_type())

        # Optional context supplied only for managed Windows launches.
        launcher.managed_launch_id = getattr(
            args.args, 'managed_launch_id', None
        )

        if launcher.managed_launch_id is not None:
            import xbmcvfs
            launcher.managed_akl_addon_data_dir = xbmcvfs.translatePath(
                'special://profile/addon_data/plugin.program.akl/'
            )
        launcher.launch()
    except Exception as e:
        logger.error('Exception while executing ROM', exc_info=e)
        kodi.notify_error('Failed to execute ROM')


# Arguments: --akl_addon_id --romcollection_id | --rom_id
def configure_launcher(args: addons.AklAddonArguments):
    logger.debug('App Launcher: Configuring ...')

    launcher = AppLauncher(
        args.get_akl_addon_id(),
        args.get_entity_id(),
        args.get_webserver_host(),
        args.get_webserver_port(),
        entity_type=args.get_entity_type())

    system_name = args.get_system_name()
    if system_name:
        launcher.launcher_settings['name'] = system_name

    if launcher.build():
        launcher.store_settings()
        return

    kodi.notify_warn('Cancelled creating launcher')


# ---------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------
# Arguments: --source_id --server_host --server_port

# ---------------------------------------------------------------------------------------------
# RUN
# ---------------------------------------------------------------------------------------------
try:
    run_plugin()
except Exception as ex:
    logger.fatal('Exception in plugin', exc_info=ex)
    kodi.notify_error("General failure")
