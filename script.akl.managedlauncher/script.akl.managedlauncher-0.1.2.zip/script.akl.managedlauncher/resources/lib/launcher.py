#
# Advanced Kodi Launcher: Default launcher implementation
#
# Copyright (c) Chrisism <crizizz@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; version 2 of the License.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# --- Python standard library ---
from __future__ import unicode_literals
from __future__ import division

import logging
import collections

# --- AKL packages ---
from akl import platforms
from akl.utils import io, kodi
from akl.launchers import LauncherABC

logger = logging.getLogger(__name__)


# -------------------------------------------------------------------------------------------------
# Default implementation for launching anything ROMs or item based using an application.
# Inherit from this base class to implement your own specific ROM App launcher.
# -------------------------------------------------------------------------------------------------
def resolve_managed_steam_shortcut(application):
    """Return a Steam App ID for a recognized Windows shortcut, or None."""
    import configparser
    import os
    import re
    from urllib.parse import urlsplit

    if not isinstance(application, str) or not application.strip():
        return None

    extension = os.path.splitext(application)[1].lower()

    if extension not in ('.lnk', '.url'):
        return None

    if not os.path.isfile(application):
        raise FileNotFoundError(
            'Managed shortcut does not exist: {}'.format(application)
        )

    def parse_steam_url(value):
        if not isinstance(value, str):
            return None

        parsed = urlsplit(value.strip())

        if parsed.scheme.lower() != 'steam':
            return None

        if parsed.netloc.lower() not in ('run', 'rungameid'):
            return None

        if parsed.query or parsed.fragment:
            return None

        match = re.fullmatch(r'/([0-9]{1,20})/?', parsed.path)

        if not match or int(match.group(1)) <= 0:
            return None

        return match.group(1)

    if extension == '.url':
        parser = configparser.ConfigParser(interpolation=None)
        parser.read(application, encoding='utf-8-sig')

        if not parser.has_section('InternetShortcut'):
            return None

        return parse_steam_url(
            parser.get('InternetShortcut', 'URL', fallback='')
        )

    if os.name != 'nt':
        raise OSError('Windows .lnk resolution requires Windows')

    import subprocess

    # PowerShell's COM shortcut resolver is used only for inspection.
    # The shortcut is never executed here.
    import base64

    script = (
        '$ErrorActionPreference = "Stop";'
        '$path = $env:AKL_MANAGED_SHORTCUT_PATH;'
        '$s = (New-Object -ComObject WScript.Shell).CreateShortcut($path);'
        '[Console]::WriteLine($s.TargetPath);'
        '[Console]::WriteLine($s.Arguments)'
    )

    encoded_script = base64.b64encode(
        script.encode('utf-16-le')
    ).decode('ascii')

    environment = os.environ.copy()
    environment['AKL_MANAGED_SHORTCUT_PATH'] = application

    result = subprocess.run(
        [
            'powershell.exe',
            '-NoProfile',
            '-NonInteractive',
            '-EncodedCommand',
            encoded_script
        ],
        env=environment,
        capture_output=True,
        text=True,
        timeout=10,
        check=False
    )

    if result.returncode != 0:
        raise RuntimeError(
            'Unable to inspect Windows shortcut: {}'.format(
                result.stderr.strip() or result.returncode
            )
        )
    lines = result.stdout.splitlines()

    if len(lines) < 2:
        return None

    target = lines[0].strip().strip('"')
    arguments = lines[1].strip()

    app_id = parse_steam_url(target)

    if app_id:
        return app_id

    if os.path.basename(target).lower() != 'steam.exe':
        return None

    match = re.fullmatch(
        r'\s*-applaunch\s+([0-9]{1,20})\s*',
        arguments,
        flags=re.IGNORECASE
    )

    if not match or int(match.group(1)) <= 0:
        return None

    return match.group(1)

def parse_managed_windows_shortcut_arguments(command_line):
    """Parse Windows shortcut arguments using CommandLineToArgvW."""
    import ctypes
    import sys
    from ctypes import wintypes

    if not isinstance(command_line, str):
        raise ValueError('Shortcut arguments must be a string')

    if not command_line.strip():
        return []

    if sys.platform != 'win32':
        raise OSError('Windows argument parsing requires Windows')

    shell32 = ctypes.WinDLL('shell32', use_last_error=True)
    kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)

    parse = shell32.CommandLineToArgvW
    parse.argtypes = [
        wintypes.LPCWSTR,
        ctypes.POINTER(ctypes.c_int)
    ]
    parse.restype = ctypes.POINTER(ctypes.c_wchar_p)

    free = kernel32.LocalFree
    free.argtypes = [ctypes.c_void_p]
    free.restype = ctypes.c_void_p

    count = ctypes.c_int()
    pointer = parse(command_line, ctypes.byref(count))

    if not pointer:
        raise ctypes.WinError(ctypes.get_last_error())

    try:
        return [pointer[index] for index in range(count.value)]
    finally:
        if free(ctypes.cast(pointer, ctypes.c_void_p)):
            raise ctypes.WinError(ctypes.get_last_error())

def resolve_managed_windows_shortcut(application):
    """Inspect an ordinary Windows .lnk without executing it."""
    import base64
    import os
    import subprocess

    if not isinstance(application, str) or not application.strip():
        return None

    if os.path.splitext(application)[1].lower() != '.lnk':
        return None

    if not os.path.isfile(application):
        raise FileNotFoundError(
            'Managed Windows shortcut not found: {}'.format(application)
        )

    if os.name != 'nt':
        raise OSError('Windows shortcut resolution requires Windows')

    script = (
        '$ErrorActionPreference = "Stop";'
        '$s = (New-Object -ComObject WScript.Shell).CreateShortcut('
        '$env:AKL_MANAGED_SHORTCUT_PATH);'
        '$result = @{'
        'target = [string]$s.TargetPath;'
        'arguments = [string]$s.Arguments;'
        'working_directory = [string]$s.WorkingDirectory'
        '};'
        '$result | ConvertTo-Json -Compress'
    )

    encoded_script = base64.b64encode(
        script.encode('utf-16-le')
    ).decode('ascii')

    environment = os.environ.copy()
    environment['AKL_MANAGED_SHORTCUT_PATH'] = application

    result = subprocess.run(
        [
            'powershell.exe',
            '-NoProfile',
            '-NonInteractive',
            '-EncodedCommand',
            encoded_script
        ],
        env=environment,
        capture_output=True,
        text=True,
        timeout=10,
        check=False
    )

    if result.returncode != 0:
        raise RuntimeError(
            'Unable to inspect Windows shortcut: {}'.format(
                result.stderr.strip() or result.returncode
            )
        )

    import json

    details = json.loads(result.stdout)

    target = details.get('target', '').strip()
    arguments = details.get('arguments', '').strip()
    working_directory = details.get('working_directory', '').strip()

    if not target:
        raise ValueError('Windows shortcut has no target')

    if os.path.splitext(target)[1].lower() != '.exe':
        raise ValueError(
            'Managed ordinary shortcuts must target an executable'
        )

    if not os.path.isfile(target):
        raise FileNotFoundError(
            'Windows shortcut target not found: {}'.format(target)
        )

    if working_directory and not os.path.isdir(working_directory):
        raise ValueError(
            'Windows shortcut working directory does not exist: {}'.format(
                working_directory
            )
        )

    return {
        'application': os.path.abspath(target),
        'shortcut_arguments': arguments,
        'working_directory': (
            os.path.abspath(working_directory)
            if working_directory else os.path.dirname(os.path.abspath(target))
        )
    }

class AppLauncher(LauncherABC):

    # --------------------------------------------------------------------------------------------
    # Core methods
    # --------------------------------------------------------------------------------------------
    def get_name(self) -> str:
        return 'Managed Windows Launcher'
     
    def get_launcher_addon_id(self) -> str:
        addon_id = kodi.get_addon_id()
        return addon_id

    # --------------------------------------------------------------------------------------------
    # Launcher build wizard methods
    # --------------------------------------------------------------------------------------------
    #
    # Creates a new launcher using a wizard of dialogs. Called by parent build() method.
    #
    def _builder_get_wizard(self, wizard):
        wizard = kodi.WizardDialog_DictionarySelection(wizard, 'application', 'Select the way to launch the files', {
            'APP': 'Using a specific application to launch',
            'FILE': 'Directly execute the file itself'})
        wizard = kodi.WizardDialog_FileBrowse(wizard, 'application', 'Select the launcher application',
                                              1, self._builder_get_appbrowser_filter, shares="programs",
                                              conditionalFunction=self._builder_will_launch_through_app)
        wizard = kodi.WizardDialog_Dummy(wizard, 'args', '', self._builder_get_arguments_from_application_path)
        wizard = kodi.WizardDialog_Keyboard(wizard, 'args', 'Application arguments')
        wizard = kodi.WizardDialog_Dummy(
            wizard, 'managed_exit_shortcut', '',
            self._builder_get_default_exit_shortcut
        )
        wizard = kodi.WizardDialog_Keyboard(
            wizard, 'managed_exit_shortcut',
            'Exit / Return to Kodi Shortcut (example: Ctrl+Shift+X)'
        )
        
        return wizard
            
    def _builder_get_default_exit_shortcut(self, input, item_key, launcher_args):
        if input:
            return input

        try:
            addon = xbmcaddon.Addon('script.akl.managedlauncher')
            default_shortcut = addon.getSetting(
                'managed_default_exit_shortcut'
            ).strip()

            if default_shortcut:
                try:
                    return self.validate_managed_exit_shortcut(
                        default_shortcut
                    )
                except ValueError as exc:
                    logger.warning(
                        'Invalid global Managed Launcher exit shortcut '
                        '"%s": %s',
                        default_shortcut, exc
                    )
                    kodi.notify_warn(
                        'Invalid default exit shortcut. '
                        'Using Ctrl+Shift+X.'
                    )
        except Exception:
            logger.exception(
                'Unable to read Managed Launcher default exit shortcut.'
            )

        return 'Ctrl+Shift+X'
    def _build_post_wizard_hook(self):
        shortcut = self.launcher_settings.get(
            'managed_exit_shortcut', 'Ctrl+Shift+X'
        )

        while True:
            try:
                shortcut = self.validate_managed_exit_shortcut(shortcut)
                break
            except ValueError as exc:
                kodi.notify_warn('Invalid exit shortcut: {}'.format(exc))
                shortcut = kodi.dialog_keyboard(
                    'Enter a valid Exit / Return to Kodi Shortcut',
                    text=shortcut if isinstance(shortcut, str) else ''
                )
                if shortcut is None:
                    return False

        self.launcher_settings['managed_exit_shortcut'] = shortcut
        self.non_blocking = True
        app = self.launcher_settings['application']
        app_FN = io.FileName(app)

        self.launcher_settings['secname'] = app_FN.getBase()
        return True
    
    def _builder_get_arguments_from_application_path(self, input, item_key, launcher_args):
        if input:
            return input
        app = launcher_args['application']
        if app == 'FILE':
            return ''
        
        appPath = io.FileName(app)
        default_arguments = platforms.emudata_get_program_arguments(appPath.getBase())

        return default_arguments

    def _builder_will_launch_through_app(self, item_key, properties) -> bool:
        if properties[item_key] == 'FILE':
            kodi.clear_windowprops([
                'AKL.SetupWizard.DefaultEmulatorsRoot'
            ])
            return False

        default_emulators_root = kodi.get_windowprop(
            'AKL.SetupWizard.DefaultEmulatorsRoot'
        )

        if default_emulators_root:
            logger.info(
                'Using Setup Wizard default Emulators root: "{}"'.format(
                    default_emulators_root
                )
            )

            properties[item_key] = default_emulators_root

        kodi.clear_windowprops([
            'AKL.SetupWizard.DefaultEmulatorsRoot'
        ])

        return True
        
    def _builder_get_edit_options(self):
        options = super()._builder_get_edit_options()
        options[self._change_application] = 'Change application ({})'.format(self.launcher_settings['application'])
        options[self._change_launcher_arguments] = "Modify Arguments: '{0}'".format(self.launcher_settings['args'])


        shortcut = self.launcher_settings.get('managed_exit_shortcut', 'Ctrl+Shift+X')
        options[self._change_managed_exit_shortcut] = (
            'Exit / Return to Kodi Shortcut ({})'.format(shortcut)
        )

        return options


    def _change_managed_exit_shortcut(self):
        current = self.launcher_settings.get(
            'managed_exit_shortcut', 'Ctrl+Shift+X'
        )
        shortcut = kodi.dialog_keyboard(
            'Exit / Return to Kodi Shortcut',
            text=current
        )

        if shortcut is None:
            return

        try:
            shortcut = self.validate_managed_exit_shortcut(shortcut)
        except ValueError as exc:
            kodi.notify_warn('Invalid exit shortcut: {}'.format(exc))
            return

        self.launcher_settings['managed_exit_shortcut'] = shortcut

    def _change_application(self):
        current_application = self.launcher_settings['application']
        
        options = collections.OrderedDict()
        options['APP'] = 'Using a specific application to launch'
        options['FILE'] = 'Directly execute the file itself'
        
        preselected = current_application if current_application == 'FILE' else 'APP'
        selected_option = kodi.OrdDictionaryDialog().select('Select the way to launch the files', options, preselected)
        
        if selected_option == 'APP':
            selected_application = kodi.browse(
                type=1,
                text='Select the launcher application',
                shares='files',
                mask='',
                preselected_path=current_application,
                useThumbs=False,
                multiple=False
            )
            if selected_application is None or selected_application == current_application:
                return
        else:
            selected_application = selected_option
        
        self.launcher_settings['application'] = selected_application

    def _change_launcher_arguments(self):
        args = self.launcher_settings['args']
        args = kodi.dialog_keyboard('Edit application arguments', text=args)

        if args is None:
            return
        self.launcher_settings['args'] = args

    # ---------------------------------------------------------------------------------------------
    # Execution methods
    # ---------------------------------------------------------------------------------------------
    def launch(self):
        """Launch through the optional managed Windows helper exclusively."""
        import sys

        if sys.platform != 'win32':
            raise RuntimeError(
                'Managed Windows Launcher requires Windows'
            )

        logger.info(
            'Managed Windows Launcher selected; preparing helper configuration'
        )
        return self.execute_managed_helper()

    @staticmethod
    def _managed_smb_to_unc(value):
        """Convert Kodi SMB URLs into Windows UNC paths for managed launches."""
        from urllib.parse import urlsplit, unquote

        if not isinstance(value, str) or not value.lower().startswith('smb://'):
            return value

        parsed = urlsplit(value)

        if (
            parsed.scheme.lower() != 'smb'
            or not parsed.netloc
            or parsed.username is not None
            or parsed.password is not None
            or parsed.query
            or parsed.fragment
        ):
            raise ValueError('Unsupported SMB URL format for Windows launch')

        server = parsed.netloc
        path = unquote(parsed.path)

        if not path.startswith('/') or path == '/':
            raise ValueError('SMB URL must contain a share')

        if '\\' in server or '/' in server:
            raise ValueError('Invalid SMB server')

        parts = path.lstrip('/').split('/')

        if any(part in ('', '.', '..') or '\\' in part for part in parts):
            raise ValueError('Unsupported SMB path component')

        return '\\\\' + server + '\\' + '\\'.join(parts)

    def build_managed_launch_configuration(self, rom_id, addon_data_dir):
        """Prepare helper configuration using existing AKL argument resolution."""
        launch_id = getattr(self, 'managed_launch_id', None)

        if not isinstance(launch_id, str) or not launch_id.strip():
            raise ValueError('Managed launch ID is required')

        if not isinstance(rom_id, str) or not rom_id.strip():
            raise ValueError('Managed ROM ID is required')

        arguments, keyword_arguments = self.get_arguments()
        application = self.get_application()

        # Windows emulators cannot generally consume Kodi smb:// URLs.
        # Translate resolved SMB paths only for the managed Windows launcher.
        arguments = [
            self._managed_smb_to_unc(argument)
            for argument in arguments
        ]
        application = self._managed_smb_to_unc(application)

        if not isinstance(application, str) or not application.strip():
            raise ValueError('Managed application path is required')

        unsupported_keywords = set(keyword_arguments) - {'non_blocking'}
        if unsupported_keywords:
            raise ValueError(
                'Managed launch does not support keyword arguments: {}'.format(
                    sorted(unsupported_keywords)
                )
            )

        if not all(isinstance(argument, str) for argument in arguments):
            raise ValueError('Managed arguments must be strings')

        steam_app_id = resolve_managed_steam_shortcut(application)

        if steam_app_id is not None and arguments:
            raise ValueError(
                'Managed Steam shortcuts do not support extra arguments'
            )

        shortcut_working_directory = None

        if steam_app_id is None:
            shortcut_details = resolve_managed_windows_shortcut(application)

            if shortcut_details is not None:
                application = shortcut_details['application']
                shortcut_arguments = (
                    parse_managed_windows_shortcut_arguments(
                        shortcut_details['shortcut_arguments']
                    )
                )
                arguments = shortcut_arguments + list(arguments)
                shortcut_working_directory = (
                    shortcut_details['working_directory']
                )

        import ctypes
        import os
        import sys

        if sys.platform != 'win32':
            raise OSError('Managed Kodi process capture requires Windows')

        kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel32.GetModuleFileNameW.argtypes = [
            ctypes.c_void_p,
            ctypes.c_wchar_p,
            ctypes.c_uint
        ]
        kernel32.GetModuleFileNameW.restype = ctypes.c_uint

        buffer = ctypes.create_unicode_buffer(32768)
        length = kernel32.GetModuleFileNameW(
            None, buffer, len(buffer)
        )

        if length == 0 or length >= len(buffer):
            raise OSError('Unable to identify the running Kodi executable')

        kodi_executable = os.path.abspath(buffer.value)

        if os.path.basename(kodi_executable).lower() != 'kodi.exe':
            raise ValueError(
                'Managed launch must originate from Kodi.exe'
            )

        kodi_pid = os.getpid()

        if steam_app_id is not None:
            return {
                'launch_type': 'steam',
                'steam_app_id': steam_app_id,
                'steam_launch_arguments': [],
                'exit_shortcut': self.launcher_settings.get(
                    'managed_exit_shortcut', 'Ctrl+Shift+X'
                ),
                'launch_id': launch_id,
                'rom_id': rom_id,
                'akl_addon_data_dir': addon_data_dir,
                'kodi_pid': kodi_pid,
                'kodi_executable': kodi_executable
            }

        return {
            'application': application,
            'arguments': list(arguments),
            **(
                {'working_directory': shortcut_working_directory}
                if shortcut_working_directory is not None else {}
            ),
            'exit_shortcut': self.launcher_settings.get(
                'managed_exit_shortcut', 'Ctrl+Shift+X'
            ),
            'launch_id': launch_id,
            'rom_id': rom_id,
            'akl_addon_data_dir': addon_data_dir,
            'kodi_pid': kodi_pid,
            'kodi_executable': kodi_executable
        }
    def validate_managed_exit_shortcut(self, shortcut):
        """Validate and normalize a managed exit shortcut."""
        if not isinstance(shortcut, str) or not shortcut.strip():
            raise ValueError('Exit shortcut must be a nonempty string')

        parts = [part.strip().upper() for part in shortcut.split('+')]
        aliases = {
            'CONTROL': 'CTRL',
            'CTL': 'CTRL',
            'MENU': 'ALT',
            'WIN': 'WINDOWS'
        }
        parts = [aliases.get(part, part) for part in parts]
        modifiers = {'CTRL', 'SHIFT', 'ALT', 'WINDOWS'}

        if any(not part for part in parts):
            raise ValueError('Exit shortcut contains an empty key')
        if len(parts) != len(set(parts)):
            raise ValueError('Exit shortcut contains duplicate keys')

        keys = [part for part in parts if part not in modifiers]
        if len(keys) != 1:
            raise ValueError('Exit shortcut must contain exactly one main key')

        key = keys[0]
        valid_key = (
            (len(key) == 1 and key in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789')
            or (
                key.startswith('F')
                and key[1:].isdigit()
                and 1 <= int(key[1:]) <= 24
            )
            or key in {'ESC', 'SPACE', 'ENTER', 'TAB'}
        )
        if not valid_key:
            raise ValueError('Unsupported exit shortcut key: {}'.format(key))

        ordered_modifiers = [
            modifier for modifier in ('CTRL', 'SHIFT', 'ALT', 'WINDOWS')
            if modifier in parts
        ]
        normalized = '+'.join(ordered_modifiers + [key])

        reserved = {
            'CTRL+ALT+DELETE', 'ALT+TAB', 'ALT+F4',
            'CTRL+SHIFT+ESC', 'WINDOWS+L', 'WINDOWS+D'
        }
        if normalized in reserved:
            raise ValueError(
                'Windows-reserved shortcut cannot be used: {}'.format(normalized)
            )

        return normalized

    def validate_managed_launch_configuration(self, config):
        """Validate helper configuration without importing helper source."""
        import os
        import re

        if not isinstance(config, dict):
            raise ValueError('Managed launch configuration must be a dictionary')

        if config.get('launch_type') == 'steam':
            app_id = config.get('steam_app_id')
            steam_arguments = config.get('steam_launch_arguments')

            if not isinstance(app_id, str) or not re.fullmatch(
                r'[0-9]{1,20}', app_id
            ) or int(app_id) <= 0:
                raise ValueError('Invalid managed Steam App ID')

            if steam_arguments != []:
                raise ValueError(
                    'Managed Steam shortcut arguments are not supported'
                )

            if 'application' in config or 'arguments' in config:
                raise ValueError(
                    'Steam configuration cannot contain emulator fields'
                )

            common = dict(config)
            common['application'] = '__steam_validation_placeholder__'
            common['arguments'] = []

            validated = self.validate_managed_launch_configuration(
                dict(common, launch_type='emulator')
            )

            validated.pop('application')
            validated.pop('arguments')
            validated['launch_type'] = 'steam'
            validated['steam_app_id'] = app_id
            validated['steam_launch_arguments'] = []
            return validated

        if config.get('launch_type') not in (None, 'emulator'):
            raise ValueError('Unsupported managed launch type')

        application = config.get('application')
        arguments = config.get('arguments')

        if not isinstance(application, str) or not application.strip():
            raise ValueError('Managed application path is required')
        if not isinstance(arguments, list):
            raise ValueError('Managed arguments must be a list')
        if not all(isinstance(argument, str) for argument in arguments):
            raise ValueError('Managed arguments must contain only strings')

        launch_id = config.get('launch_id')
        rom_id = config.get('rom_id')
        addon_data_dir = config.get('akl_addon_data_dir')

        if not isinstance(launch_id, str) or not re.fullmatch(
            r'[A-Za-z0-9_-]{1,128}', launch_id
        ):
            raise ValueError('Invalid managed launch ID')
        if not isinstance(rom_id, str) or not rom_id.strip():
            raise ValueError('Invalid managed ROM ID')
        if not isinstance(addon_data_dir, str) or not addon_data_dir.strip():
            raise ValueError('Invalid AKL addon data directory')
        if not os.path.isdir(addon_data_dir):
            raise ValueError(
                'AKL addon data directory does not exist: {}'.format(
                    addon_data_dir
                )
            )

        shortcut = self.validate_managed_exit_shortcut(
            config.get('exit_shortcut', 'Ctrl+Shift+X')
        )

        validated = dict(config)
        validated['launch_id'] = launch_id
        validated['rom_id'] = rom_id
        validated['akl_addon_data_dir'] = os.path.abspath(addon_data_dir)
        validated['exit_shortcut'] = shortcut
        return validated

    def write_managed_launch_configuration(self, config, path):
        """Write a validated helper configuration without executing it."""
        import json
        import os
        import tempfile

        validated = self.validate_managed_launch_configuration(config)
        destination = os.path.abspath(os.fspath(path))
        directory = os.path.dirname(destination)

        if not os.path.isdir(directory):
            raise ValueError(
                'Managed configuration destination directory does not exist'
            )

        temporary_path = None

        try:
            with tempfile.NamedTemporaryFile(
                mode='w',
                encoding='utf-8',
                suffix='.tmp',
                prefix='akl_managed_',
                dir=directory,
                delete=False
            ) as handle:
                temporary_path = handle.name
                json.dump(validated, handle, indent=2)
                handle.write('\n')

            os.replace(temporary_path, destination)
            temporary_path = None
        finally:
            if temporary_path is not None:
                try:
                    os.unlink(temporary_path)
                except OSError:
                    pass

        return destination
    def prepare_managed_launch(self):
        """Prepare the helper configuration without executing anything."""
        import os

        launch_id = getattr(self, 'managed_launch_id', None)
        addon_data_dir = getattr(
            self, 'managed_akl_addon_data_dir', None
        )
        rom_id = self.rom_id

        if not isinstance(addon_data_dir, str) or not addon_data_dir.strip():
            raise ValueError('Managed AKL addon data directory is required')

        if not os.path.isdir(addon_data_dir):
            raise ValueError('Managed AKL addon data directory does not exist')

        config = self.build_managed_launch_configuration(
            rom_id, addon_data_dir
        )

        # Remove acknowledgments belonging only to this launch ID.
        # Never accept stale startup or bookkeeping confirmation.
        import re

        validated_id = config.get('launch_id')

        if not isinstance(validated_id, str) or not re.fullmatch(
            r'[A-Za-z0-9_-]{1,128}', validated_id
        ):
            raise ValueError('Invalid managed launch ID')

        for prefix in (
            'managed_emulator_started_',
            'managed_launch_ack_'
        ):
            acknowledgment = os.path.join(
                addon_data_dir,
                '{}{}.json'.format(prefix, validated_id)
            )

            try:
                os.remove(acknowledgment)
            except FileNotFoundError:
                pass

        destination = os.path.join(
            addon_data_dir,
            'managed_launch_config_{}.json'.format(launch_id)
        )

        return self.write_managed_launch_configuration(
            config, destination
        )
    def start_managed_helper(self, executable, config_path, helper_script=None):
        """Start a separate managed helper without waiting for it to exit."""
        import os
        import subprocess

        executable = os.path.abspath(os.fspath(executable))
        config_path = os.path.abspath(os.fspath(config_path))

        if not os.path.isfile(executable):
            raise FileNotFoundError(
                'Managed helper executable does not exist: {}'.format(
                    executable
                )
            )

        if not os.path.isfile(config_path):
            raise FileNotFoundError(
                'Managed configuration file does not exist: {}'.format(
                    config_path
                )
            )

        command = [executable]

        if helper_script is not None:
            helper_script = os.path.abspath(os.fspath(helper_script))

            if not os.path.isfile(helper_script):
                raise FileNotFoundError(
                    'Managed helper script does not exist: {}'.format(
                        helper_script
                    )
                )

            command.append(helper_script)

        command.append(config_path)

        creationflags = getattr(
            subprocess, 'CREATE_NEW_PROCESS_GROUP', 0
        )

        process = subprocess.Popen(
            command,
            cwd=os.path.dirname(executable),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=creationflags
        )

        logger.info(
            'Managed helper started: PID %s', process.pid
        )

        return process.pid

    def execute_managed_helper(self):
        """Start the packaged Windows helper without blocking Kodi."""
        import os

        helper_exe = os.path.normpath(os.path.join(
            os.path.dirname(__file__),
            "..",
            "bin",
            "AKLManagedHelper",
            "AKLManagedHelper.exe"
        ))

        if not os.path.isfile(helper_exe):
            raise FileNotFoundError(
                "Managed Windows helper executable not found: {}".format(
                    helper_exe
                )
            )

        config_path = self.prepare_managed_launch()

        return self.start_managed_helper(
            helper_exe,
            config_path
        )

    def get_application(self) -> str:
        if 'application' not in self.launcher_settings:
            logger.error('LauncherABC::launch() No application argument defined')
            return None
        
        if self.launcher_settings['application'] == 'FILE':
            return "$ROM$"
        
        application = io.FileName(self.launcher_settings['application'])
        
        # --- Check for errors and abort if errors found ---
        if not application.exists():
            logger.error('Launching app not found "{0}"'.format(application.getPath()))
            kodi.notify_warn('App {0} not found.'.format(application.getPath()))
            return None
        
        return application.getPath()
