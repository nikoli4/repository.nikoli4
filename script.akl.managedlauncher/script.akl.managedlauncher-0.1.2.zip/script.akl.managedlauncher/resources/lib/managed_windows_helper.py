"""Detached Windows process helper for AKL managed launches."""

import json
import logging
import os
import subprocess
import sys
import threading


logger = logging.getLogger("akl.managed_windows")


def parse_exit_shortcut(shortcut):
    """Validate and normalize a Windows exit shortcut."""
    if not isinstance(shortcut, str) or not shortcut.strip():
        raise ValueError("Exit shortcut must be a nonempty string")

    parts = [part.strip().upper() for part in shortcut.split("+")]

    aliases = {
        "CONTROL": "CTRL",
        "CTL": "CTRL",
        "MENU": "ALT",
        "WIN": "WINDOWS",
    }

    parts = [aliases.get(part, part) for part in parts]

    modifiers = {"CTRL", "SHIFT", "ALT", "WINDOWS"}

    if any(not part for part in parts):
        raise ValueError("Exit shortcut contains an empty key")

    if len(parts) != len(set(parts)):
        raise ValueError("Exit shortcut contains duplicate keys")

    keys = [part for part in parts if part not in modifiers]

    if len(keys) != 1:
        raise ValueError("Exit shortcut must contain exactly one main key")

    key = keys[0]

    valid_key = (
        (len(key) == 1 and key in "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
        or (
            key.startswith("F")
            and key[1:].isdigit()
            and 1 <= int(key[1:]) <= 24
        )
        or key in {"ESC", "SPACE", "ENTER", "TAB"}
    )

    if not valid_key:
        raise ValueError("Unsupported exit shortcut key: {}".format(key))

    ordered_modifiers = [
        modifier for modifier in ("CTRL", "SHIFT", "ALT", "WINDOWS")
        if modifier in parts
    ]

    normalized = "+".join(ordered_modifiers + [key])

    reserved = {
        "CTRL+ALT+DELETE",
        "ALT+TAB",
        "ALT+F4",
        "CTRL+SHIFT+ESC",
        "WINDOWS+L",
        "WINDOWS+D",
    }

    if normalized in reserved:
        raise ValueError(
            "Windows-reserved shortcut cannot be used: {}".format(normalized)
        )

    return normalized

def shortcut_to_windows_keys(shortcut):
    """Convert a validated shortcut to Windows hotkey constants."""
    normalized = parse_exit_shortcut(shortcut)
    parts = normalized.split("+")

    modifier_flags = {
        "ALT": 0x0001,
        "CTRL": 0x0002,
        "SHIFT": 0x0004,
        "WINDOWS": 0x0008,
    }

    modifiers = 0

    for part in parts[:-1]:
        modifiers |= modifier_flags[part]

    key = parts[-1]

    if len(key) == 1:
        virtual_key = ord(key)
    elif key.startswith("F") and key[1:].isdigit():
        virtual_key = 0x70 + int(key[1:]) - 1
    else:
        special_keys = {
            "ESC": 0x1B,
            "SPACE": 0x20,
            "ENTER": 0x0D,
            "TAB": 0x09,
        }
        virtual_key = special_keys[key]

    return modifiers, virtual_key

def wait_for_exit_shortcut(shortcut):
    """Wait for a Windows global hotkey and release it afterward."""
    import ctypes
    from ctypes import wintypes

    if sys.platform != "win32":
        raise RuntimeError("Windows hotkeys require Windows")

    user32 = ctypes.WinDLL("user32", use_last_error=True)

    user32.RegisterHotKey.argtypes = [
        wintypes.HWND,
        ctypes.c_int,
        wintypes.UINT,
        wintypes.UINT,
    ]
    user32.RegisterHotKey.restype = wintypes.BOOL

    user32.UnregisterHotKey.argtypes = [
        wintypes.HWND,
        ctypes.c_int,
    ]
    user32.UnregisterHotKey.restype = wintypes.BOOL

    user32.GetMessageW.argtypes = [
        ctypes.POINTER(wintypes.MSG),
        wintypes.HWND,
        wintypes.UINT,
        wintypes.UINT,
    ]
    user32.GetMessageW.restype = ctypes.c_int

    modifiers, virtual_key = shortcut_to_windows_keys(shortcut)

    hotkey_id = 1
    wm_hotkey = 0x0312
    mod_norepeat = 0x4000

    if not user32.RegisterHotKey(
        None,
        hotkey_id,
        modifiers | mod_norepeat,
        virtual_key,
    ):
        raise ctypes.WinError(ctypes.get_last_error())

    try:
        logger.info("Registered exit shortcut: %s", shortcut)

        message = wintypes.MSG()

        while True:
            result = user32.GetMessageW(
                ctypes.byref(message),
                None,
                0,
                0,
            )

            if result == -1:
                raise ctypes.WinError(ctypes.get_last_error())

            if result == 0:
                return False

            if message.message == wm_hotkey:
                if message.wParam == hotkey_id:
                    logger.info("Exit shortcut detected: %s", shortcut)
                    return True

    finally:
        user32.UnregisterHotKey(None, hotkey_id)
        logger.info("Exit shortcut unregistered")

class ManagedHotkeyListener:
    """Thread-owned Windows hotkey with cooperative shutdown."""

    def __init__(self, shortcut):
        self.shortcut = parse_exit_shortcut(shortcut)
        self.detected = threading.Event()
        self.ready = threading.Event()
        self.stopped = threading.Event()
        self.error = None
        self.thread_id = None
        self.thread = None

    def start(self):
        if self.thread is not None:
            raise RuntimeError("Hotkey listener already started")

        self.thread = threading.Thread(
            target=self._run,
            name="AKLManagedHotkey",
            daemon=True,
        )
        self.thread.start()

        if not self.ready.wait(timeout=5):
            raise RuntimeError("Hotkey listener startup timed out")

        if self.error is not None:
            raise self.error

    def stop(self):
        if self.thread is None:
            return

        if self.thread.is_alive() and self.thread_id is not None:
            import ctypes

            user32 = ctypes.WinDLL("user32", use_last_error=True)
            user32.PostThreadMessageW(
                self.thread_id, 0x0012, 0, 0
            )

        self.thread.join(timeout=5)

        if self.thread.is_alive():
            raise RuntimeError("Hotkey listener did not stop")

    def _run(self):
        import ctypes
        from ctypes import wintypes

        user32 = ctypes.WinDLL("user32", use_last_error=True)

        user32.RegisterHotKey.argtypes = [
            wintypes.HWND, ctypes.c_int,
            wintypes.UINT, wintypes.UINT,
        ]
        user32.RegisterHotKey.restype = wintypes.BOOL

        user32.UnregisterHotKey.argtypes = [
            wintypes.HWND, ctypes.c_int,
        ]
        user32.UnregisterHotKey.restype = wintypes.BOOL

        user32.GetMessageW.argtypes = [
            ctypes.POINTER(wintypes.MSG),
            wintypes.HWND, wintypes.UINT, wintypes.UINT,
        ]
        user32.GetMessageW.restype = ctypes.c_int


        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.GetCurrentThreadId.restype = wintypes.DWORD

        hotkey_id = 1
        registered = False

        try:
            modifiers, key = shortcut_to_windows_keys(
                self.shortcut
            )

            message = wintypes.MSG()

            # Ensure this thread owns a Windows message queue.
            user32.PeekMessageW(
                ctypes.byref(message), None, 0, 0, 0
            )

            self.thread_id = kernel32.GetCurrentThreadId()

            registered = bool(user32.RegisterHotKey(
                None, hotkey_id,
                modifiers | 0x4000, key,
            ))

            if not registered:
                raise ctypes.WinError(ctypes.get_last_error())

            logger.info(
                "Managed hotkey registered: %s",
                self.shortcut,
            )
            self.ready.set()

            while True:
                result = user32.GetMessageW(
                    ctypes.byref(message), None, 0, 0
                )

                if result == -1:
                    raise ctypes.WinError(ctypes.get_last_error())

                if result == 0:
                    break

                if message.message == 0x0312:
                    if message.wParam == hotkey_id:
                        self.detected.set()
                        logger.info(
                            "Managed hotkey detected: %s",
                            self.shortcut,
                        )
                        break

        except Exception as exc:
            self.error = exc
            logger.exception("Managed hotkey listener failed")
            self.ready.set()

        finally:
            if registered:
                user32.UnregisterHotKey(None, hotkey_id)
                logger.info("Managed hotkey unregistered")

            self.stopped.set()

class ManagedTrayIcon:
    """Windows notification icon with a Return to Kodi menu."""

    WM_USER_TRAY = 0x0400 + 21
    WM_COMMAND = 0x0111
    WM_RBUTTONUP = 0x0205
    WM_CONTEXTMENU = 0x007B
    WM_CLOSE = 0x0010
    WM_DESTROY = 0x0002
    WM_NULL = 0x0000
    NIM_ADD = 0
    NIM_DELETE = 2
    NIF_MESSAGE = 1
    NIF_ICON = 2
    NIF_TIP = 4
    MENU_RETURN = 1001

    def __init__(self, exit_requested, icon_path):
        self.exit_requested = exit_requested
        self.icon_path = icon_path
        self.ready = threading.Event()
        self.stopped = threading.Event()
        self.error = None
        self.thread = None
        self.hwnd = None
        self._wndproc = None

    def start(self):
        if self.thread is not None:
            raise RuntimeError("Tray already started")

        self.thread = threading.Thread(
            target=self._run,
            name="AKLManagedTray",
            daemon=True,
        )
        self.thread.start()

        if not self.ready.wait(timeout=5):
            raise RuntimeError("Tray startup timed out")

        if self.error is not None:
            raise self.error

    def stop(self):
        if self.thread is None:
            return

        if self.thread.is_alive() and self.hwnd:
            import ctypes
            user32 = ctypes.WinDLL("user32", use_last_error=True)
            user32.PostMessageW(self.hwnd, self.WM_CLOSE, 0, 0)

        self.thread.join(timeout=5)

        if self.thread.is_alive():
            raise RuntimeError("Tray thread did not stop")

    def _run(self):
        import ctypes
        from ctypes import wintypes

        user32 = ctypes.WinDLL("user32", use_last_error=True)
        shell32 = ctypes.WinDLL("shell32", use_last_error=True)
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

        LRESULT = ctypes.c_ssize_t
        WNDPROC = ctypes.WINFUNCTYPE(
            LRESULT,
            wintypes.HWND,
            wintypes.UINT,
            wintypes.WPARAM,
            wintypes.LPARAM,
        )

        class WNDCLASSW(ctypes.Structure):
            _fields_ = [
                ("style", wintypes.UINT),
                ("lpfnWndProc", WNDPROC),
                ("cbClsExtra", ctypes.c_int),
                ("cbWndExtra", ctypes.c_int),
                ("hInstance", wintypes.HINSTANCE),
                ("hIcon", wintypes.HICON),
                ("hCursor", wintypes.HANDLE),
                ("hbrBackground", wintypes.HBRUSH),
                ("lpszMenuName", wintypes.LPCWSTR),
                ("lpszClassName", wintypes.LPCWSTR),
            ]

        class NOTIFYICONDATAW(ctypes.Structure):
            _fields_ = [
                ("cbSize", wintypes.DWORD),
                ("hWnd", wintypes.HWND),
                ("uID", wintypes.UINT),
                ("uFlags", wintypes.UINT),
                ("uCallbackMessage", wintypes.UINT),
                ("hIcon", wintypes.HICON),
                ("szTip", wintypes.WCHAR * 128),
                ("dwState", wintypes.DWORD),
                ("dwStateMask", wintypes.DWORD),
                ("szInfo", wintypes.WCHAR * 256),
                ("uTimeoutOrVersion", wintypes.UINT),
                ("szInfoTitle", wintypes.WCHAR * 64),
                ("dwInfoFlags", wintypes.DWORD),
                ("guidItem", ctypes.c_byte * 16),
                ("hBalloonIcon", wintypes.HICON),
            ]

        user32.DefWindowProcW.argtypes = [
            wintypes.HWND, wintypes.UINT,
            wintypes.WPARAM, wintypes.LPARAM,
        ]
        user32.DefWindowProcW.restype = LRESULT

        user32.RegisterClassW.argtypes = [ctypes.POINTER(WNDCLASSW)]
        user32.RegisterClassW.restype = wintypes.ATOM

        user32.CreateWindowExW.argtypes = [
            wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR,
            wintypes.DWORD, ctypes.c_int, ctypes.c_int,
            ctypes.c_int, ctypes.c_int, wintypes.HWND,
            wintypes.HMENU, wintypes.HINSTANCE, wintypes.LPVOID,
        ]
        user32.CreateWindowExW.restype = wintypes.HWND

        user32.LoadImageW.argtypes = [
            wintypes.HINSTANCE, wintypes.LPCWSTR,
            wintypes.UINT, ctypes.c_int, ctypes.c_int, wintypes.UINT,
        ]
        user32.LoadImageW.restype = wintypes.HANDLE

        user32.DestroyIcon.argtypes = [wintypes.HICON]
        user32.DestroyIcon.restype = wintypes.BOOL

        user32.CreatePopupMenu.restype = wintypes.HMENU
        user32.AppendMenuW.argtypes = [
            wintypes.HMENU, wintypes.UINT,
            ctypes.c_size_t, wintypes.LPCWSTR,
        ]
        user32.AppendMenuW.restype = wintypes.BOOL

        user32.TrackPopupMenu.argtypes = [
            wintypes.HMENU, wintypes.UINT,
            ctypes.c_int, ctypes.c_int,
            ctypes.c_int, wintypes.HWND, ctypes.POINTER(wintypes.RECT),
        ]
        user32.TrackPopupMenu.restype = wintypes.BOOL

        user32.DestroyMenu.argtypes = [wintypes.HMENU]
        user32.DestroyMenu.restype = wintypes.BOOL

        user32.GetCursorPos.argtypes = [ctypes.POINTER(wintypes.POINT)]
        user32.GetCursorPos.restype = wintypes.BOOL

        user32.SetForegroundWindow.argtypes = [wintypes.HWND]
        user32.SetForegroundWindow.restype = wintypes.BOOL

        user32.DestroyWindow.argtypes = [wintypes.HWND]
        user32.DestroyWindow.restype = wintypes.BOOL

        user32.GetMessageW.argtypes = [
            ctypes.POINTER(wintypes.MSG),
            wintypes.HWND, wintypes.UINT, wintypes.UINT,
        ]
        user32.GetMessageW.restype = ctypes.c_int

        shell32.Shell_NotifyIconW.argtypes = [
            wintypes.DWORD, ctypes.POINTER(NOTIFYICONDATAW),
        ]
        shell32.Shell_NotifyIconW.restype = wintypes.BOOL


        kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
        kernel32.GetModuleHandleW.restype = wintypes.HMODULE

        user32.PostMessageW.argtypes = [
            wintypes.HWND, wintypes.UINT,
            wintypes.WPARAM, wintypes.LPARAM,
        ]
        user32.PostMessageW.restype = wintypes.BOOL

        user32.PostQuitMessage.argtypes = [ctypes.c_int]
        user32.PostQuitMessage.restype = None

        user32.TranslateMessage.argtypes = [
            ctypes.POINTER(wintypes.MSG)
        ]
        user32.TranslateMessage.restype = wintypes.BOOL

        user32.DispatchMessageW.argtypes = [
            ctypes.POINTER(wintypes.MSG)
        ]
        user32.DispatchMessageW.restype = LRESULT

        instance = kernel32.GetModuleHandleW(None)
        class_name = "AKLManagedTrayWindow"
        icon = None
        icon_added = False
        window = None
        icon_data = None

        def show_menu(hwnd):
            menu = user32.CreatePopupMenu()
            if not menu:
                return

            try:
                user32.AppendMenuW(
                    menu, 0, self.MENU_RETURN, "Return to Kodi"
                )
                point = wintypes.POINT()
                if user32.GetCursorPos(ctypes.byref(point)):
                    user32.SetForegroundWindow(hwnd)
                    user32.TrackPopupMenu(
                        menu, 0, point.x, point.y, 0, hwnd, None
                    )
                    user32.PostMessageW(hwnd, self.WM_NULL, 0, 0)
            finally:
                user32.DestroyMenu(menu)

        def window_proc(hwnd, message, wparam, lparam):
            if message == self.WM_USER_TRAY:
                if lparam in (self.WM_RBUTTONUP, self.WM_CONTEXTMENU):
                    show_menu(hwnd)
                    return 0
            elif message == self.WM_COMMAND:
                if (wparam & 0xFFFF) == self.MENU_RETURN:
                    self.exit_requested.set()
                    return 0
            elif message == self.WM_CLOSE:
                user32.DestroyWindow(hwnd)
                return 0
            elif message == self.WM_DESTROY:
                user32.PostQuitMessage(0)
                return 0

            return user32.DefWindowProcW(
                hwnd, message, wparam, lparam
            )

        try:
            self._wndproc = WNDPROC(window_proc)

            window_class = WNDCLASSW()
            window_class.lpfnWndProc = self._wndproc
            window_class.hInstance = instance
            window_class.lpszClassName = class_name

            if not user32.RegisterClassW(ctypes.byref(window_class)):
                raise ctypes.WinError(ctypes.get_last_error())

            window = user32.CreateWindowExW(
                0, class_name, "AKL Managed Launcher",
                0, 0, 0, 0, 0, None, None, instance, None
            )

            if not window:
                raise ctypes.WinError(ctypes.get_last_error())

            self.hwnd = window

            icon = user32.LoadImageW(
                None, self.icon_path, 1, 0, 0, 0x0010
            )

            if not icon:
                raise ctypes.WinError(ctypes.get_last_error())

            icon_data = NOTIFYICONDATAW()
            icon_data.cbSize = ctypes.sizeof(NOTIFYICONDATAW)
            icon_data.hWnd = window
            icon_data.uID = 1
            icon_data.uFlags = (
                self.NIF_MESSAGE | self.NIF_ICON | self.NIF_TIP
            )
            icon_data.uCallbackMessage = self.WM_USER_TRAY
            icon_data.hIcon = icon
            icon_data.szTip = "AKL Managed Launcher"

            if not shell32.Shell_NotifyIconW(
                self.NIM_ADD, ctypes.byref(icon_data)
            ):
                raise ctypes.WinError(ctypes.get_last_error())

            icon_added = True
            self.ready.set()

            message = wintypes.MSG()
            while True:
                result = user32.GetMessageW(
                    ctypes.byref(message), None, 0, 0
                )
                if result == -1:
                    raise ctypes.WinError(ctypes.get_last_error())
                if result == 0:
                    break
                user32.TranslateMessage(ctypes.byref(message))
                user32.DispatchMessageW(ctypes.byref(message))

        except Exception as exc:
            self.error = exc
            logger.exception("Managed tray failed")
            self.ready.set()

        finally:
            if icon_added and icon_data is not None:
                shell32.Shell_NotifyIconW(
                    self.NIM_DELETE, ctypes.byref(icon_data)
                )

            if window and user32.IsWindow(window):
                user32.DestroyWindow(window)

            if icon:
                user32.DestroyIcon(icon)

            self.hwnd = None
            self.stopped.set()

def monitor_managed_process(process, shortcut, exit_requested=None):
    """Monitor a process and its exit hotkey without terminating either."""
    if exit_requested is None:
        exit_requested = threading.Event()

    listener = ManagedHotkeyListener(shortcut)

    try:
        listener.start()

        logger.info(
            "Monitoring process PID %d with shortcut %s",
            process.pid,
            listener.shortcut,
        )

        while True:
            return_code = process.poll()

            if return_code is not None:
                logger.info(
                    "Monitored process exited with code %d",
                    return_code,
                )
                return "process_exited"

            if listener.error is not None:
                raise listener.error

            if listener.detected.is_set():
                logger.info(
                    "Exit shortcut requested for PID %d",
                    process.pid,
                )
                return "hotkey_detected"

            if exit_requested.is_set():
                logger.info(
                    "External exit requested for PID %d",
                    process.pid,
                )
                return "hotkey_detected"

            if listener.stopped.is_set():
                raise RuntimeError(
                    "Hotkey listener stopped unexpectedly"
                )

            # Event wait avoids a busy polling loop.
            listener.detected.wait(timeout=0.1)

    finally:
        listener.stop()

def request_graceful_close(process, timeout=10):
    """Request normal Windows shutdown for a specific process."""
    import ctypes
    import time
    from ctypes import wintypes

    if sys.platform != "win32":
        raise RuntimeError("Graceful window close requires Windows")

    if process.poll() is not None:
        logger.info("Process PID %d already exited", process.pid)
        return True

    user32 = ctypes.WinDLL("user32", use_last_error=True)

    enum_windows = user32.EnumWindows
    enum_windows.argtypes = [
        ctypes.WINFUNCTYPE(
            wintypes.BOOL,
            wintypes.HWND,
            wintypes.LPARAM,
        ),
        wintypes.LPARAM,
    ]
    enum_windows.restype = wintypes.BOOL

    get_window_pid = user32.GetWindowThreadProcessId
    get_window_pid.argtypes = [
        wintypes.HWND,
        ctypes.POINTER(wintypes.DWORD),
    ]
    get_window_pid.restype = wintypes.DWORD

    is_window_visible = user32.IsWindowVisible
    is_window_visible.argtypes = [wintypes.HWND]
    is_window_visible.restype = wintypes.BOOL

    post_message = user32.PostMessageW
    post_message.argtypes = [
        wintypes.HWND,
        wintypes.UINT,
        wintypes.WPARAM,
        wintypes.LPARAM,
    ]
    post_message.restype = wintypes.BOOL

    windows = []

    callback_type = ctypes.WINFUNCTYPE(
        wintypes.BOOL,
        wintypes.HWND,
        wintypes.LPARAM,
    )

    def callback(hwnd, lparam):
        pid = wintypes.DWORD()

        get_window_pid(hwnd, ctypes.byref(pid))

        if pid.value == process.pid and is_window_visible(hwnd):
            windows.append(hwnd)

        return True

    callback_ref = callback_type(callback)

    if not enum_windows(callback_ref, 0):
        raise ctypes.WinError(ctypes.get_last_error())

    if not windows:
        logger.warning(
            "No visible window found for PID %d",
            process.pid,
        )
        return False

    for hwnd in windows:
        if not post_message(hwnd, 0x0010, 0, 0):
            raise ctypes.WinError(ctypes.get_last_error())

        logger.info(
            "WM_CLOSE sent to PID %d, HWND %s",
            process.pid,
            hwnd,
        )

    try:
        process.wait(timeout=timeout)
        logger.info(
            "Process PID %d exited after WM_CLOSE",
            process.pid,
        )
        return True

    except subprocess.TimeoutExpired:
        logger.warning(
            "Process PID %d did not exit within %s seconds",
            process.pid,
            timeout,
        )
        return False

def run_managed_process(
    process, shortcut, close_timeout=10, exit_requested=None
):
    """Monitor a process and gracefully close it on exit request."""
    result = monitor_managed_process(
        process, shortcut, exit_requested=exit_requested
    )

    if result == "process_exited":
        logger.info(
            "Managed process PID %d exited normally",
            process.pid,
        )
        return "process_exited"

    if result == "hotkey_detected":
        logger.info(
            "Requesting graceful shutdown for PID %d",
            process.pid,
        )

        closed = request_graceful_close(
            process,
            timeout=close_timeout,
        )

        if closed:
            logger.info(
                "Managed process PID %d closed gracefully",
                process.pid,
            )
            return "hotkey_closed"

        logger.warning(
            "Managed process PID %d remains running",
            process.pid,
        )
        return "close_timeout"

    raise RuntimeError(
        "Unexpected managed monitor result: {}".format(result)
    )

def managed_launch_ack_path(addon_data_dir, launch_id):
    """Construct the acknowledgment path for one managed launch."""
    import re

    if not isinstance(launch_id, str) or not re.fullmatch(
        r"[A-Za-z0-9_-]{1,128}", launch_id
    ):
        raise ValueError("Invalid managed launch ID")

    if not isinstance(addon_data_dir, str) or not addon_data_dir.strip():
        raise ValueError("Invalid AKL addon data directory")

    filename = "managed_launch_ack_{}.json".format(launch_id)
    return os.path.join(addon_data_dir, filename)

def verify_managed_launch_ack(path, launch_id, rom_id):
    """Verify an acknowledgment belongs to the expected managed launch."""
    if not isinstance(launch_id, str) or not isinstance(rom_id, str):
        return False

    if not launch_id or not rom_id:
        return False

    try:
        with open(path, "r", encoding="utf-8-sig") as handle:
            payload = json.load(handle)
    except (OSError, ValueError, UnicodeError):
        return False

    if not isinstance(payload, dict):
        return False

    return (
        payload.get("launch_id") == launch_id
        and payload.get("rom_id") == rom_id
        and payload.get("status") == "complete"
    )

def wait_for_managed_launch_ack(path, launch_id, rom_id, timeout=30, interval=0.2):
    """Wait for a matching completion acknowledgment without waiting forever."""
    import time
    import re

    if not isinstance(launch_id, str) or not re.fullmatch(
        r"[A-Za-z0-9_-]{1,128}", launch_id
    ):
        raise ValueError("Invalid managed launch ID")

    if not isinstance(rom_id, str) or not rom_id:
        raise ValueError("Invalid managed ROM ID")

    if timeout < 0 or interval <= 0:
        raise ValueError("Invalid acknowledgment wait timing")

    deadline = time.monotonic() + timeout

    while True:
        if verify_managed_launch_ack(path, launch_id, rom_id):
            return True

        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return False

        time.sleep(min(interval, remaining))

def await_managed_bookkeeping(config, timeout=30):
    """Require verified AKL bookkeeping before any Kodi shutdown."""
    if not isinstance(config, dict):
        raise ValueError("Managed configuration must be a dictionary")

    launch_id = config.get("launch_id")
    rom_id = config.get("rom_id")
    addon_data_dir = config.get("akl_addon_data_dir")

    ack_path = managed_launch_ack_path(addon_data_dir, launch_id)

    if not isinstance(rom_id, str) or not rom_id:
        raise ValueError("Managed launch requires a ROM ID")

    if not wait_for_managed_launch_ack(
        ack_path, launch_id, rom_id, timeout=timeout
    ):
        logger.warning(
            "Managed bookkeeping acknowledgment timed out: launch_id=%s",
            launch_id
        )
        return False

    logger.info(
        "Managed bookkeeping acknowledgment verified: launch_id=%s",
        launch_id
    )
    return True

def validate_managed_bookkeeping_config(config):
    """Validate identifiers and the AKL acknowledgment directory."""
    import re

    if not isinstance(config, dict):
        raise ValueError("Managed configuration must be a dictionary")

    launch_id = config.get("launch_id")
    rom_id = config.get("rom_id")
    addon_data_dir = config.get("akl_addon_data_dir")

    if not isinstance(launch_id, str) or not re.fullmatch(
        r"[A-Za-z0-9_-]{1,128}", launch_id
    ):
        raise ValueError("Invalid managed launch ID")

    if not isinstance(rom_id, str) or not rom_id.strip():
        raise ValueError("Invalid managed ROM ID")

    if not isinstance(addon_data_dir, str) or not addon_data_dir.strip():
        raise ValueError("Invalid AKL addon data directory")

    if not os.path.isdir(addon_data_dir):
        raise ValueError(
            "AKL addon data directory does not exist: {}".format(
                addon_data_dir
            )
        )

    return {
        "launch_id": launch_id,
        "rom_id": rom_id,
        "akl_addon_data_dir": os.path.abspath(addon_data_dir)
    }

def may_shutdown_kodi_after_bookkeeping(config, timeout=30):
    """Allow Kodi shutdown only after verified managed bookkeeping."""
    validated = validate_managed_bookkeeping_config(config)

    if not await_managed_bookkeeping(validated, timeout=timeout):
        logger.warning(
            "Kodi shutdown blocked: managed bookkeeping incomplete"
        )
        return False

    logger.info(
        "Kodi shutdown safety gate passed: launch_id=%s",
        validated["launch_id"]
    )
    return True

def validate_managed_steam_config(config):
    """Validate Steam launch configuration without starting any process."""
    import re

    if not isinstance(config, dict):
        raise ValueError("Steam configuration must be a dictionary")

    if config.get("launch_type") != "steam":
        raise ValueError("Not a managed Steam configuration")

    app_id = config.get("steam_app_id")
    if (
        not isinstance(app_id, str)
        or not re.fullmatch(r"[0-9]{1,20}", app_id)
        or int(app_id) <= 0
    ):
        raise ValueError("Invalid Steam App ID")

    arguments = config.get("steam_launch_arguments")
    if not isinstance(arguments, list) or not all(
        isinstance(argument, str) for argument in arguments
    ):
        raise ValueError("Invalid Steam launch arguments")

    shortcut = parse_exit_shortcut(
        config.get("exit_shortcut", "Ctrl+Shift+X")
    )

    validated = dict(config)
    validated.update(validate_managed_bookkeeping_config(config))
    validated.update(validate_managed_kodi_config(config))

    validated["launch_type"] = "steam"
    validated["steam_app_id"] = app_id
    validated["steam_launch_arguments"] = list(arguments)
    validated["exit_shortcut"] = shortcut

    return validated

def start_managed_steam_after_kodi_shutdown(
    config, kodi_shutdown_verified=False, steam_root=None
):
    """Request Steam launch only after confirmed Kodi shutdown and recheck."""
    if kodi_shutdown_verified is not True:
        raise RuntimeError(
            "Managed Steam launch blocked: Kodi shutdown unconfirmed"
        )

    try:
        # Recheck immediately before the Steam request. Another
        # application may have started the game while Kodi exited.
        validated = require_managed_steam_ready(
            config, steam_root=steam_root
        )

        # Do not silently accept a different Kodi process starting
        # between shutdown confirmation and the Steam request.
        kodi = validate_managed_kodi_config(validated)

        if is_kodi_already_running(kodi["kodi_executable"]):
            raise RuntimeError(
                "Managed Steam launch blocked: Kodi is running again"
            )

        steam_url = request_managed_steam_launch(
            validated, kodi_shutdown_verified=True
        )

        logger.info(
            "Managed Steam launch request sent: %s",
            steam_url
        )

        return steam_url

    except Exception:
        logger.exception(
            "Managed Steam launch stage failed; attempting Kodi recovery"
        )

        try:
            recovered = recover_kodi_after_managed_steam(
                config, steam_root=steam_root
            )

            logger.info(
                "Managed Steam launch-failure recovery result: %s",
                recovered
            )

        except Exception:
            logger.exception(
                "Managed Steam launch-failure recovery raised an exception"
            )

        # Never report success after a failed or uncertain request.
        raise

def prepare_managed_steam_execution(config, steam_root=None):
    """Authorize Steam execution only after confirmed Kodi shutdown."""
    # Validate and check for an existing game before touching Kodi.
    require_managed_steam_ready(
        config, steam_root=steam_root
    )

    try:
        shutdown_confirmed = shutdown_kodi_for_managed_steam(
            config, steam_root=steam_root
        )
    except Exception:
        logger.exception(
            "Managed Steam Kodi shutdown raised an exception"
        )
        shutdown_confirmed = False

    if shutdown_confirmed is not True:
        logger.error(
            "Managed Steam execution blocked: Kodi shutdown unconfirmed"
        )

        recovered = recover_failed_managed_steam_shutdown(
            config, steam_root=steam_root
        )

        logger.info(
            "Managed Steam shutdown-failure recovery result: %s",
            recovered
        )

        # Recovery never authorizes Steam execution.
        return False

    logger.info(
        "Managed Steam execution preparation completed: "
        "Kodi shutdown verified"
    )

    return True

def recover_failed_managed_steam_shutdown(config, steam_root=None):
    """Recover Kodi after an unsuccessful or ambiguous Steam shutdown."""
    logger.warning(
        "Managed Steam shutdown failed or was unconfirmed; "
        "Steam launch remains blocked"
    )

    # This function never sends a Steam launch request.
    # The recovery helper independently checks game processes,
    # the original Kodi PID, and other running Kodi instances.
    try:
        recovered = recover_kodi_after_managed_steam(
            config, steam_root=steam_root
        )

        if recovered is True:
            logger.info(
                "Managed Steam shutdown recovery completed or Kodi "
                "was already running"
            )
            return True

        logger.error(
            "Managed Steam shutdown recovery could not be confirmed"
        )
        return False

    except Exception:
        logger.exception(
            "Managed Steam shutdown recovery encountered an error"
        )
        return False

def recover_kodi_after_managed_steam(config, steam_root=None):
    """Restore Kodi only when Steam game processes are confirmed absent."""
    try:
        validated = validate_managed_steam_config(config)
        kodi = validate_managed_kodi_config(validated)
        app_id = validated["steam_app_id"]

        processes = find_steam_game_processes(
            app_id, steam_root
        )

        if not isinstance(processes, list):
            raise RuntimeError(
                "Steam recovery blocked: invalid process inspection"
            )

        if processes:
            logger.warning(
                "Steam recovery blocked: game %s still has processes",
                app_id
            )
            return False

        if verify_kodi_process(
            kodi["kodi_pid"], kodi["kodi_executable"]
        ):
            logger.info(
                "Steam recovery unnecessary: original Kodi still running"
            )
            return True

        if is_kodi_already_running(kodi["kodi_executable"]):
            logger.info(
                "Steam recovery unnecessary: Kodi already reopened"
            )
            return True

        restarted = restart_managed_kodi(validated, True)

        if restarted is not True:
            logger.error(
                "Steam recovery failed: Kodi restart was not confirmed"
            )
            return False

        logger.info(
            "Steam recovery requested Kodi restart: launch_id=%s",
            validated["launch_id"]
        )
        return True

    except Exception:
        logger.exception(
            "Steam recovery could not safely restore Kodi"
        )
        return False

def shutdown_kodi_for_managed_steam(config, steam_root=None):
    """Shut down verified Kodi only after Steam pre-launch checks pass."""
    validated = require_managed_steam_ready(
        config, steam_root=steam_root
    )

    kodi = validate_managed_kodi_config(validated)

    if not verify_kodi_process(
        kodi["kodi_pid"], kodi["kodi_executable"]
    ):
        raise RuntimeError(
            "Managed Steam shutdown blocked: Kodi process identity "
            "could not be verified"
        )

    logger.info(
        "Managed Steam Kodi shutdown requested: launch_id=%s",
        validated["launch_id"]
    )

    # Steam bookkeeping occurs after actual game startup.
    # Do not use the emulator's suspended-process acknowledgment.
    closed = safely_shutdown_verified_kodi(
        validated, True, timeout=20
    )

    if closed is not True:
        logger.error(
            "Managed Steam Kodi shutdown could not be confirmed"
        )
        return False

    # Independently verify that the original Kodi process is gone.
    if verify_kodi_process(
        kodi["kodi_pid"], kodi["kodi_executable"]
    ):
        logger.error(
            "Managed Steam Kodi shutdown rejected: original process "
            "still appears to be running"
        )
        return False

    logger.info(
        "Managed Steam Kodi shutdown verified: launch_id=%s",
        validated["launch_id"]
    )

    return True

def require_managed_steam_ready(config, steam_root=None):
    """Require a supported Steam launch with no existing game session."""
    validated = validate_managed_steam_config(config)

    if validated["steam_launch_arguments"]:
        raise ValueError(
            "Managed Steam execution does not yet support "
            "additional launch arguments"
        )

    result = check_managed_steam_prelaunch(
        validated, steam_root=steam_root
    )

    if not isinstance(result, dict):
        raise RuntimeError(
            "Managed Steam pre-launch check returned an invalid result"
        )

    if result.get("steam_app_id") != validated["steam_app_id"]:
        raise RuntimeError(
            "Managed Steam pre-launch App ID mismatch"
        )

    if result.get("status") != "ready":
        raise RuntimeError(
            "Managed Steam launch blocked: {}".format(
                result.get("status", "unknown")
            )
        )

    if result.get("existing_pids") != []:
        raise RuntimeError(
            "Managed Steam launch blocked: existing game processes"
        )

    if not result.get("game_directory"):
        raise RuntimeError(
            "Managed Steam launch blocked: installation unverified"
        )

    logger.info(
        "Managed Steam readiness verified: App ID %s",
        validated["steam_app_id"]
    )

    return validated

def check_managed_steam_prelaunch(config, steam_root=None):
    """Verify Steam game availability and reject existing game sessions."""
    validated = validate_managed_steam_config(config)
    app_id = validated["steam_app_id"]

    game_directory = resolve_steam_game_directory(
        app_id, steam_root
    )

    if not game_directory:
        logger.warning(
            "Managed Steam pre-launch: installation not found for %s",
            app_id
        )
        return {
            "status": "not_installed",
            "steam_app_id": app_id,
            "game_directory": None,
            "existing_pids": []
        }

    processes = find_steam_game_processes(
        app_id, steam_root
    )

    if not isinstance(processes, list):
        raise RuntimeError(
            "Steam process inspection returned an invalid result"
        )

    existing_pids = []

    for entry in processes:
        if not isinstance(entry, dict):
            raise RuntimeError(
                "Steam process inspection returned an invalid entry"
            )

        pid = entry.get("pid")

        if (
            not isinstance(pid, int)
            or isinstance(pid, bool)
            or pid <= 0
        ):
            raise RuntimeError(
                "Steam process inspection returned an invalid PID"
            )

        existing_pids.append(pid)

    existing_pids = sorted(set(existing_pids))

    if existing_pids:
        logger.warning(
            "Managed Steam pre-launch blocked: game %s already running: %s",
            app_id, existing_pids
        )
        status = "already_running"
    else:
        logger.info(
            "Managed Steam pre-launch ready: %s",
            app_id
        )
        status = "ready"

    return {
        "status": status,
        "steam_app_id": app_id,
        "game_directory": game_directory,
        "existing_pids": existing_pids
    }

def request_managed_steam_launch(config, kodi_shutdown_verified=False):
    """Send a Steam launch request only after verified Kodi shutdown."""
    import re

    if kodi_shutdown_verified is not True:
        raise RuntimeError(
            "Steam launch blocked: Kodi shutdown has not been verified"
        )

    if not isinstance(config, dict):
        raise ValueError("Invalid Steam launch configuration")

    if config.get("launch_type") != "steam":
        raise ValueError("Not a managed Steam configuration")

    app_id = config.get("steam_app_id")

    if (
        not isinstance(app_id, str)
        or not re.fullmatch(r"[0-9]{1,20}", app_id)
        or int(app_id) <= 0
    ):
        raise ValueError("Invalid Steam App ID")

    arguments = config.get("steam_launch_arguments")

    if not isinstance(arguments, list) or not all(
        isinstance(argument, str) for argument in arguments
    ):
        raise ValueError("Invalid Steam launch arguments")

    if arguments:
        raise ValueError(
            "Additional Steam arguments are not yet supported "
            "by managed execution"
        )

    if sys.platform != "win32":
        raise OSError("Managed Steam launch requires Windows")

    steam_url = "steam://rungameid/{}".format(app_id)

    logger.info(
        "Sending managed Steam launch request for App ID %s",
        app_id
    )

    os.startfile(steam_url)

    return steam_url

def load_managed_steam_configuration(path):
    """Load and validate a Steam configuration without launching anything."""
    import os

    if not isinstance(path, str) or not path.strip():
        raise ValueError("Invalid Steam configuration path")

    if not os.path.isfile(path):
        raise FileNotFoundError(
            "Steam configuration file not found: {}".format(path)
        )

    with open(path, "r", encoding="utf-8-sig") as handle:
        config = json.load(handle)

    return validate_managed_steam_config(config)

def load_configuration(path):
    """Load and validate a managed-launch configuration."""
    with open(path, "r", encoding="utf-8-sig") as handle:
        config = json.load(handle)

    if not isinstance(config, dict):
        raise ValueError("Managed-launch configuration must be an object")

    application = config.get("application")
    arguments = config.get("arguments", [])

    if not isinstance(application, str) or not application.strip():
        raise ValueError("Missing application path")

    if not isinstance(arguments, list):
        raise ValueError("Arguments must be a list")

    if not all(isinstance(arg, str) for arg in arguments):
        raise ValueError("Every argument must be a string")

    if "working_directory" in config:
        working_directory = config["working_directory"]

        if (
            not isinstance(working_directory, str)
            or not working_directory.strip()
        ):
            raise ValueError(
                "Managed working directory must be a nonempty string"
            )

        if not os.path.isdir(working_directory):
            raise ValueError(
                "Managed working directory does not exist: {}".format(
                    working_directory
                )
            )

    shortcut = config.get("exit_shortcut", "Ctrl+Shift+X")
    config["exit_shortcut"] = parse_exit_shortcut(shortcut)

    # Require matching bookkeeping information for managed launches.
    config.update(validate_managed_bookkeeping_config(config))
    config.update(validate_managed_kodi_config(config))

    return config


def monitor_managed_steam_execution(
    config, exit_requested=None, steam_root=None
):
    """Monitor a managed Steam game and recover Kodi when safe."""
    validated = validate_managed_steam_config(config)
    app_id = validated["steam_app_id"]
    shortcut = validated["exit_shortcut"]

    startup_callback = create_managed_steam_startup_callback(
        validated
    )

    result = None
    monitoring_error = None

    try:
        result = run_steam_game_with_hotkey(
            app_id,
            shortcut,
            exit_requested=exit_requested,
            steam_root=steam_root,
            on_game_started=startup_callback,
        )

        logger.info(
            "Managed Steam monitoring finished: app_id=%s result=%s",
            app_id, result
        )

    except Exception as error:
        monitoring_error = error
        logger.exception(
            "Managed Steam monitoring failed: app_id=%s",
            app_id
        )

    # A graceful-close timeout can occur while the game is still
    # cleaning up. Wait for verified process exit without killing it.
    if result == "close_timeout":
        import time

        recovery_deadline = time.monotonic() + 60

        logger.warning(
            "Steam game %s exceeded graceful-close timeout; "
            "waiting up to 60 additional seconds for process exit",
            app_id
        )

        while time.monotonic() < recovery_deadline:
            try:
                remaining = find_steam_game_processes(
                    app_id, steam_root
                )

                if not isinstance(remaining, list):
                    raise RuntimeError(
                        "Invalid Steam process inspection result"
                    )

            except Exception:
                logger.exception(
                    "Delayed Steam recovery process inspection failed"
                )
                break

            if not remaining:
                logger.info(
                    "Steam game %s finished exiting during delayed recovery",
                    app_id
                )
                result = "hotkey_closed"
                break

            time.sleep(2)

    # Recovery independently verifies that the game is no longer
    # running. A close_timeout or monitoring exception must never
    # bypass that check.
    try:
        recovered = recover_kodi_after_managed_steam(
            validated, steam_root=steam_root
        )
    except Exception:
        recovered = False
        logger.exception(
            "Managed Steam Kodi recovery raised an exception"
        )

    if recovered is not True:
        logger.error(
            "Managed Steam Kodi recovery not confirmed: app_id=%s",
            app_id
        )

        if monitoring_error is not None:
            raise RuntimeError(
                "Managed Steam monitoring failed and Kodi recovery "
                "could not be confirmed"
            ) from monitoring_error

        raise RuntimeError(
            "Managed Steam Kodi recovery could not be confirmed"
        )

    if monitoring_error is not None:
        raise RuntimeError(
            "Managed Steam monitoring failed; Kodi recovery completed"
        ) from monitoring_error

    if result not in (
        "process_exited",
        "hotkey_closed",
        "startup_timeout",
        "close_timeout",
    ):
        raise RuntimeError(
            "Unexpected managed Steam monitoring result: {}".format(
                result
            )
        )

    return result


def create_managed_steam_startup_callback(config):
    """Create a callback that durably confirms verified Steam startup."""
    validated = validate_managed_steam_config(config)
    confirmed = False

    def on_game_started(pid):
        nonlocal confirmed

        if confirmed:
            raise RuntimeError(
                "Managed Steam startup callback invoked more than once"
            )

        # The writer independently checks that this PID belongs
        # to the requested Steam game before publishing the record.
        destination = write_managed_steam_started(validated, pid)

        if not isinstance(destination, str) or not destination:
            raise RuntimeError(
                "Managed Steam startup confirmation was not written"
            )

        confirmed = True

        logger.info(
            "Managed Steam startup confirmed: app_id=%s pid=%s",
            validated["steam_app_id"], pid
        )

        return destination

    return on_game_started


def write_managed_steam_started(config, pid):
    """Record verified Steam game startup without emulator acknowledgments."""
    import tempfile
    import time

    validated = validate_managed_steam_config(config)

    if not isinstance(pid, int) or isinstance(pid, bool) or pid <= 0:
        raise ValueError("Invalid Steam game process ID")

    app_id = validated["steam_app_id"]
    processes = find_steam_game_processes(app_id)

    matching = [
        entry for entry in processes
        if entry.get("pid") == pid
    ]

    if not matching:
        raise ValueError(
            "Steam startup confirmation refused: game PID not verified"
        )

    launch_id = validated["launch_id"]
    addon_data_dir = validated["akl_addon_data_dir"]

    destination = os.path.join(
        addon_data_dir,
        "managed_steam_started_{}.json".format(launch_id)
    )

    payload = {
        "launch_id": launch_id,
        "rom_id": validated["rom_id"],
        "steam_app_id": app_id,
        "pid": pid,
        "status": "started",
        "timestamp": time.time()
    }

    temporary_path = None

    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            suffix=".tmp",
            prefix="managed_steam_started_",
            dir=addon_data_dir,
            delete=False
        ) as handle:
            temporary_path = handle.name
            json.dump(payload, handle, indent=2)
            handle.flush()
            os.fsync(handle.fileno())

        # Publish only once. Never replace an existing confirmation.
        # Hard linking gives us atomic create-if-absent behavior.
        os.link(temporary_path, destination)
        return destination

    finally:
        if temporary_path is not None:
            try:
                os.remove(temporary_path)
            except OSError:
                pass

def write_managed_emulator_started(config, pid):
    """Atomically acknowledge that the emulator process was created."""
    import tempfile
    import time

    validated = validate_managed_bookkeeping_config(config)

    if not isinstance(pid, int) or isinstance(pid, bool) or pid <= 0:
        raise ValueError("Invalid managed emulator process ID")

    launch_id = validated["launch_id"]
    rom_id = validated["rom_id"]
    addon_data_dir = validated["akl_addon_data_dir"]

    destination = os.path.join(
        addon_data_dir,
        "managed_emulator_started_{}.json".format(launch_id)
    )

    payload = {
        "launch_id": launch_id,
        "rom_id": rom_id,
        "pid": pid,
        "status": "started",
        "timestamp": time.time()
    }

    temporary_path = None

    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            suffix=".tmp",
            prefix="managed_emulator_started_",
            dir=addon_data_dir,
            delete=False
        ) as handle:
            temporary_path = handle.name
            json.dump(payload, handle, indent=2)

        os.replace(temporary_path, destination)
        temporary_path = None

    finally:
        if temporary_path is not None:
            try:
                os.remove(temporary_path)
            except OSError:
                pass

    return destination

def find_kodi_executable(config=None):
    """Find a Kodi executable without launching or terminating it."""
    import os

    config = config or {}
    configured = config.get("kodi_executable")

    if configured:
        if not isinstance(configured, str):
            raise ValueError("Kodi executable path must be a string")
        if not os.path.isfile(configured):
            raise FileNotFoundError(
                "Configured Kodi executable not found: {}".format(configured)
            )
        return os.path.abspath(configured)

    candidates = [
        os.path.join(
            os.environ.get("ProgramFiles", r"C:\Program Files"),
            "Kodi", "Kodi.exe"
        ),
        os.path.join(
            os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
            "Kodi", "Kodi.exe"
        )
    ]

    for candidate in candidates:
        if os.path.isfile(candidate):
            return os.path.abspath(candidate)

    raise FileNotFoundError("Kodi executable could not be located")

def get_windows_process_executable(pid):
    """Read the executable path of a Windows process without changing it."""
    import ctypes
    from ctypes import wintypes

    if not isinstance(pid, int) or isinstance(pid, bool) or pid <= 0:
        raise ValueError("Invalid process ID")

    if sys.platform != "win32":
        raise OSError("Windows process inspection requires Windows")

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel32.OpenProcess.restype = wintypes.HANDLE

    kernel32.QueryFullProcessImageNameW.argtypes = [
        wintypes.HANDLE,
        wintypes.DWORD,
        wintypes.LPWSTR,
        ctypes.POINTER(wintypes.DWORD)
    ]
    kernel32.QueryFullProcessImageNameW.restype = wintypes.BOOL

    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL

    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000

    handle = kernel32.OpenProcess(
        PROCESS_QUERY_LIMITED_INFORMATION, False, pid
    )

    if not handle:
        raise ctypes.WinError(ctypes.get_last_error())

    try:
        size = wintypes.DWORD(32768)
        buffer = ctypes.create_unicode_buffer(size.value)

        if not kernel32.QueryFullProcessImageNameW(
            handle, 0, buffer, ctypes.byref(size)
        ):
            raise ctypes.WinError(ctypes.get_last_error())

        return os.path.abspath(buffer.value)
    finally:
        kernel32.CloseHandle(handle)

def validate_managed_kodi_config(config):
    """Validate the Kodi process identity supplied by the launcher."""
    import os

    if not isinstance(config, dict):
        raise ValueError("Kodi configuration must be a dictionary")

    kodi_pid = config.get("kodi_pid")
    kodi_executable = config.get("kodi_executable")

    if (
        not isinstance(kodi_pid, int)
        or isinstance(kodi_pid, bool)
        or kodi_pid <= 0
    ):
        raise ValueError("Invalid Kodi process ID")

    if (
        not isinstance(kodi_executable, str)
        or not kodi_executable.strip()
    ):
        raise ValueError("Invalid Kodi executable path")

    kodi_executable = os.path.abspath(kodi_executable)

    if os.path.basename(kodi_executable).lower() != "kodi.exe":
        raise ValueError("Kodi executable must be Kodi.exe")

    if not os.path.isfile(kodi_executable):
        raise FileNotFoundError(
            "Kodi executable not found: {}".format(kodi_executable)
        )

    return {
        "kodi_pid": kodi_pid,
        "kodi_executable": kodi_executable
    }


def verify_kodi_process(kodi_pid, kodi_executable):
    """Verify that a PID belongs to the expected Kodi executable."""
    import os

    if not isinstance(kodi_executable, str) or not kodi_executable.strip():
        raise ValueError("Invalid Kodi executable path")

    expected = os.path.normcase(os.path.abspath(kodi_executable))

    if os.path.basename(expected).lower() != "kodi.exe":
        raise ValueError("Expected executable must be Kodi.exe")

    try:
        actual = get_windows_process_executable(kodi_pid)
    except OSError:
        return False

    actual = os.path.normcase(os.path.abspath(actual))
    return actual == expected

def request_graceful_kodi_shutdown(kodi_pid):
    """Request a graceful close of windows owned by a Kodi process."""
    import ctypes
    from ctypes import wintypes

    if not isinstance(kodi_pid, int) or isinstance(kodi_pid, bool) or kodi_pid <= 0:
        raise ValueError("Invalid Kodi process ID")

    if sys.platform != "win32":
        raise OSError("Kodi shutdown requires Windows")

    user32 = ctypes.WinDLL("user32", use_last_error=True)
    user32.EnumWindows.argtypes = [
        ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM),
        wintypes.LPARAM
    ]
    user32.EnumWindows.restype = wintypes.BOOL
    user32.GetWindowThreadProcessId.argtypes = [
        wintypes.HWND, ctypes.POINTER(wintypes.DWORD)
    ]
    user32.GetWindowThreadProcessId.restype = wintypes.DWORD
    user32.PostMessageW.argtypes = [
        wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM
    ]
    user32.PostMessageW.restype = wintypes.BOOL

    WM_CLOSE = 0x0010
    matched = []

    callback_type = ctypes.WINFUNCTYPE(
        wintypes.BOOL, wintypes.HWND, wintypes.LPARAM
    )

    def callback(hwnd, lparam):
        process_id = wintypes.DWORD()
        user32.GetWindowThreadProcessId(
            hwnd, ctypes.byref(process_id)
        )

        if process_id.value == kodi_pid:
            if user32.PostMessageW(hwnd, WM_CLOSE, 0, 0):
                matched.append(hwnd)
        return True

    callback_ref = callback_type(callback)

    if not user32.EnumWindows(callback_ref, 0):
        raise OSError("Failed to enumerate Windows windows")

    if not matched:
        logger.warning(
            "No Kodi windows accepted graceful shutdown: pid=%s",
            kodi_pid
        )
        return False

    logger.info(
        "Graceful Kodi shutdown requested: pid=%s windows=%s",
        kodi_pid, len(matched)
    )
    return True

def open_verified_kodi_process_handle(kodi_pid, kodi_executable):
    """Open and verify the original Kodi process using one Windows handle."""
    import ctypes
    from ctypes import wintypes

    validated = validate_managed_kodi_config({
        "kodi_pid": kodi_pid,
        "kodi_executable": kodi_executable
    })

    if sys.platform != "win32":
        raise OSError("Verified Kodi process handles require Windows")

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    kernel32.OpenProcess.argtypes = [
        wintypes.DWORD, wintypes.BOOL, wintypes.DWORD
    ]
    kernel32.OpenProcess.restype = wintypes.HANDLE

    kernel32.QueryFullProcessImageNameW.argtypes = [
        wintypes.HANDLE,
        wintypes.DWORD,
        wintypes.LPWSTR,
        ctypes.POINTER(wintypes.DWORD)
    ]
    kernel32.QueryFullProcessImageNameW.restype = wintypes.BOOL

    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL

    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    SYNCHRONIZE = 0x00100000

    handle = kernel32.OpenProcess(
        PROCESS_QUERY_LIMITED_INFORMATION | SYNCHRONIZE,
        False,
        validated["kodi_pid"]
    )

    if not handle:
        raise ctypes.WinError(ctypes.get_last_error())

    try:
        size = wintypes.DWORD(32768)
        buffer = ctypes.create_unicode_buffer(size.value)

        if not kernel32.QueryFullProcessImageNameW(
            handle, 0, buffer, ctypes.byref(size)
        ):
            raise ctypes.WinError(ctypes.get_last_error())

        actual = os.path.normcase(os.path.abspath(buffer.value))
        expected = os.path.normcase(validated["kodi_executable"])

        if actual != expected:
            raise RuntimeError(
                "Kodi process executable does not match expected path"
            )

        return handle

    except BaseException:
        kernel32.CloseHandle(handle)
        raise


def wait_for_verified_kodi_handle(handle, timeout=20):
    """Wait for the already-verified Kodi process to exit."""
    import ctypes
    from ctypes import wintypes
    import math

    if not isinstance(handle, int) or isinstance(handle, bool) or handle <= 0:
        raise ValueError("Invalid verified Kodi process handle")

    if (
        not isinstance(timeout, (int, float))
        or isinstance(timeout, bool)
        or not math.isfinite(timeout)
        or not 0 <= timeout <= 120
    ):
        raise ValueError("Invalid Kodi exit timeout")

    if sys.platform != "win32":
        raise OSError("Verified Kodi handle waiting requires Windows")

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    kernel32.WaitForSingleObject.argtypes = [
        wintypes.HANDLE, wintypes.DWORD
    ]
    kernel32.WaitForSingleObject.restype = wintypes.DWORD

    result = kernel32.WaitForSingleObject(
        handle, int(timeout * 1000)
    )

    if result == 0:
        return True

    if result == 258:
        return False

    if result == 0xFFFFFFFF:
        raise ctypes.WinError(ctypes.get_last_error())

    raise OSError(
        "Unexpected verified Kodi wait result: {}".format(result)
    )


def wait_for_windows_process_handle(pid, timeout=20):
    """Wait for a specific Windows process to exit using its handle."""
    import ctypes
    from ctypes import wintypes

    if not isinstance(pid, int) or isinstance(pid, bool) or pid <= 0:
        raise ValueError("Invalid Windows process ID")

    if (
        not isinstance(timeout, (int, float))
        or isinstance(timeout, bool)
        or not 0 <= timeout <= 120
    ):
        raise ValueError("Invalid process wait timeout")

    if sys.platform != "win32":
        raise OSError("Process-handle waiting requires Windows")

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    kernel32.OpenProcess.argtypes = [
        wintypes.DWORD, wintypes.BOOL, wintypes.DWORD
    ]
    kernel32.OpenProcess.restype = wintypes.HANDLE

    kernel32.WaitForSingleObject.argtypes = [
        wintypes.HANDLE, wintypes.DWORD
    ]
    kernel32.WaitForSingleObject.restype = wintypes.DWORD

    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL

    SYNCHRONIZE = 0x00100000
    WAIT_OBJECT_0 = 0
    WAIT_TIMEOUT = 258
    WAIT_FAILED = 0xFFFFFFFF

    handle = kernel32.OpenProcess(SYNCHRONIZE, False, pid)

    if not handle:
        raise ctypes.WinError(ctypes.get_last_error())

    try:
        milliseconds = int(timeout * 1000)
        result = kernel32.WaitForSingleObject(
            handle, milliseconds
        )

        if result == WAIT_OBJECT_0:
            return True

        if result == WAIT_TIMEOUT:
            return False

        if result == WAIT_FAILED:
            raise ctypes.WinError(ctypes.get_last_error())

        raise OSError(
            "Unexpected Windows process wait result: {}".format(result)
        )
    finally:
        kernel32.CloseHandle(handle)


def wait_for_kodi_exit(kodi_pid, kodi_executable, timeout=20):
    """Wait for the original Kodi process to exit without terminating it."""
    import time

    if not isinstance(kodi_pid, int) or isinstance(kodi_pid, bool) or kodi_pid <= 0:
        raise ValueError("Invalid Kodi process ID")

    if not isinstance(timeout, (int, float)) or isinstance(timeout, bool):
        raise ValueError("Invalid Kodi exit timeout")

    if timeout < 0 or timeout > 120:
        raise ValueError("Kodi exit timeout must be between 0 and 120 seconds")

    validated = validate_managed_kodi_config({
        "kodi_pid": kodi_pid,
        "kodi_executable": kodi_executable
    })

    deadline = time.monotonic() + timeout

    while True:
        try:
            actual = get_windows_process_executable(kodi_pid)
        except OSError as exc:
            error_code = getattr(exc, "winerror", None)

            if error_code == 87:
                logger.info(
                    "Original Kodi process no longer exists: pid=%s",
                    kodi_pid
                )
                return True

            logger.warning(
                "Cannot confirm Kodi exit: pid=%s error=%s",
                kodi_pid, exc
            )
            return False

        if os.path.normcase(os.path.abspath(actual)) != os.path.normcase(
            validated["kodi_executable"]
        ):
            logger.warning(
                "Kodi PID identity changed while waiting: pid=%s",
                kodi_pid
            )
            return False

        remaining = deadline - time.monotonic()

        if remaining <= 0:
            logger.warning(
                "Timed out waiting for Kodi to exit: pid=%s",
                kodi_pid
            )
            return False

        time.sleep(min(0.2, remaining))


def request_managed_kodi_shutdown(config, bookkeeping_ready):
    """Request Kodi shutdown only after verified managed bookkeeping."""
    if bookkeeping_ready is not True:
        logger.warning(
            "Kodi shutdown refused: managed bookkeeping not confirmed"
        )
        return False

    validated = validate_managed_kodi_config(config)
    kodi_pid = validated["kodi_pid"]
    kodi_executable = validated["kodi_executable"]

    if not verify_kodi_process(kodi_pid, kodi_executable):
        logger.warning(
            "Kodi shutdown refused: process identity mismatch, pid=%s",
            kodi_pid
        )
        return False

    logger.info(
        "Requesting graceful Kodi shutdown: pid=%s",
        kodi_pid
    )

    return request_graceful_kodi_shutdown(kodi_pid)


def shutdown_verified_kodi(config, bookkeeping_ready, timeout=20):
    """Gracefully close verified Kodi and confirm its process exited."""
    import ctypes
    from ctypes import wintypes

    if bookkeeping_ready is not True:
        logger.warning("Verified Kodi shutdown refused: bookkeeping incomplete")
        return False

    validated = validate_managed_kodi_config(config)
    kodi_pid = validated["kodi_pid"]

    handle = open_verified_kodi_process_handle(
        kodi_pid, validated["kodi_executable"]
    )

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL

    try:
        if not request_graceful_kodi_shutdown(kodi_pid):
            logger.warning(
                "Graceful Kodi shutdown request failed: pid=%s",
                kodi_pid
            )
            return False

        if not wait_for_verified_kodi_handle(handle, timeout=timeout):
            logger.warning(
                "Kodi did not exit after shutdown request: pid=%s",
                kodi_pid
            )
            return False

        logger.info(
            "Verified Kodi process exited successfully: pid=%s",
            kodi_pid
        )
        return True

    finally:
        kernel32.CloseHandle(handle)


def safely_shutdown_verified_kodi(config, bookkeeping_ready, timeout=20):
    """Prevent Kodi shutdown errors from interrupting emulator monitoring."""
    if bookkeeping_ready is not True:
        logger.warning(
            "Kodi shutdown skipped: managed bookkeeping incomplete"
        )
        return False

    try:
        return shutdown_verified_kodi(
            config, bookkeeping_ready, timeout=timeout
        ) is True
    except Exception:
        logger.exception(
            "Verified Kodi shutdown failed; emulator monitoring will continue"
        )
        return False


def request_steam_game_close(
    app_id, timeout=15, poll_interval=0.5, steam_root=None
):
    """Request a Steam game's visible windows to close; leave Steam running."""
    import ctypes
    import time
    from ctypes import wintypes

    if sys.platform != "win32":
        raise RuntimeError("Steam graceful close requires Windows")

    if timeout <= 0 or poll_interval <= 0:
        raise ValueError("Invalid Steam close timeout or polling interval")

    processes = find_steam_game_processes(app_id, steam_root)

    if not processes:
        logger.info("Steam game %s already stopped", app_id)
        return True

    windows = find_steam_game_windows(app_id)

    if not windows:
        logger.warning(
            "Steam game %s has running processes but no visible windows",
            app_id,
        )
        return False

    user32 = ctypes.WinDLL("user32", use_last_error=True)
    post_message = user32.PostMessageW
    post_message.argtypes = [
        wintypes.HWND,
        wintypes.UINT,
        wintypes.WPARAM,
        wintypes.LPARAM,
    ]
    post_message.restype = wintypes.BOOL

    sent = 0

    for window in windows:
        hwnd = wintypes.HWND(window["hwnd"])
        owner_pid = wintypes.DWORD()

        get_window_pid = user32.GetWindowThreadProcessId
        get_window_pid.argtypes = [
            wintypes.HWND,
            ctypes.POINTER(wintypes.DWORD),
        ]
        get_window_pid.restype = wintypes.DWORD

        get_window_pid(hwnd, ctypes.byref(owner_pid))

        current_processes = {
            entry["pid"]: entry
            for entry in find_steam_game_processes(app_id, steam_root)
        }

        current = current_processes.get(owner_pid.value)

        if current is None:
            logger.warning(
                "Skipping Steam window %s: owner no longer matches game",
                window["hwnd"],
            )
            continue

        if current["executable"] != window["executable"]:
            logger.warning(
                "Skipping Steam window %s: executable changed",
                window["hwnd"],
            )
            continue

        if not post_message(hwnd, 0x0010, 0, 0):
            logger.warning(
                "WM_CLOSE failed for Steam game window %s",
                window["hwnd"],
            )
            continue

        sent += 1
        logger.info(
            "WM_CLOSE sent to Steam game %s PID %s HWND %s",
            app_id,
            owner_pid.value,
            window["hwnd"],
        )

    if sent == 0:
        logger.warning("No close requests sent to Steam game %s", app_id)
        return False

    deadline = time.monotonic() + timeout

    while time.monotonic() < deadline:
        if not find_steam_game_processes(app_id, steam_root):
            logger.info("Steam game %s stopped after WM_CLOSE", app_id)
            return True

        time.sleep(poll_interval)

    if not find_steam_game_processes(app_id, steam_root):
        return True

    logger.warning(
        "Steam game %s remains running after graceful-close timeout",
        app_id,
    )
    return False

def find_steam_game_windows(app_id, steam_root=None):
    """Identify visible windows owned by processes of one Steam game."""
    import ctypes
    from ctypes import wintypes

    if sys.platform != "win32":
        raise OSError("Steam window discovery requires Windows")

    processes = {
        entry["pid"]: entry
        for entry in find_steam_game_processes(app_id, steam_root)
    }

    if not processes:
        return []

    user32 = ctypes.WinDLL("user32", use_last_error=True)

    callback_type = ctypes.WINFUNCTYPE(
        wintypes.BOOL, wintypes.HWND, wintypes.LPARAM
    )

    user32.EnumWindows.argtypes = [callback_type, wintypes.LPARAM]
    user32.EnumWindows.restype = wintypes.BOOL

    user32.GetWindowThreadProcessId.argtypes = [
        wintypes.HWND, ctypes.POINTER(wintypes.DWORD)
    ]
    user32.GetWindowThreadProcessId.restype = wintypes.DWORD

    user32.IsWindowVisible.argtypes = [wintypes.HWND]
    user32.IsWindowVisible.restype = wintypes.BOOL

    user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
    user32.GetWindowTextLengthW.restype = ctypes.c_int

    user32.GetWindowTextW.argtypes = [
        wintypes.HWND, wintypes.LPWSTR, ctypes.c_int
    ]
    user32.GetWindowTextW.restype = ctypes.c_int

    windows = []

    def callback(hwnd, lparam):
        if not user32.IsWindowVisible(hwnd):
            return True

        owner_pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(
            hwnd, ctypes.byref(owner_pid)
        )

        process = processes.get(owner_pid.value)
        if process is None:
            return True

        length = user32.GetWindowTextLengthW(hwnd)
        buffer = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buffer, len(buffer))

        windows.append({
            "hwnd": int(hwnd),
            "pid": owner_pid.value,
            "title": buffer.value,
            "executable": process["executable"],
        })

        return True

    callback_ref = callback_type(callback)

    if not user32.EnumWindows(callback_ref, 0):
        raise ctypes.WinError(ctypes.get_last_error())

    return windows

def run_steam_game_with_hotkey(
    app_id, shortcut, exit_requested=None,
    startup_timeout=60, exit_grace_period=5,
    poll_interval=0.5, close_timeout=45, steam_root=None,
    on_game_started=None
):
    """Monitor a Steam game and close it gracefully on an exit request."""
    if close_timeout <= 0:
        raise ValueError("Invalid Steam graceful-close timeout")

    result = monitor_steam_game_with_hotkey(
        app_id,
        shortcut,
        exit_requested=exit_requested,
        startup_timeout=startup_timeout,
        exit_grace_period=exit_grace_period,
        poll_interval=poll_interval,
        steam_root=steam_root,
        on_game_started=on_game_started,
    )

    if result in ("process_exited", "startup_timeout"):
        return result

    if result == "hotkey_detected":
        logger.info(
            "Requesting graceful shutdown of Steam game %s", app_id
        )

        closed = request_steam_game_close(
            app_id,
            timeout=close_timeout,
            poll_interval=poll_interval,
            steam_root=steam_root,
        )

        if not closed:
            logger.warning(
                "Steam game %s remains running after exit request",
                app_id,
            )
            return "close_timeout"

        # Verify the complete game process set is gone.
        if find_steam_game_processes(app_id, steam_root):
            logger.warning(
                "Steam game %s still has running processes",
                app_id,
            )
            return "close_timeout"

        logger.info(
            "Steam game %s closed after exit request", app_id
        )
        return "hotkey_closed"

    raise RuntimeError(
        "Unexpected Steam monitor result: {}".format(result)
    )

def monitor_steam_game_with_hotkey(
    app_id, shortcut, exit_requested=None,
    startup_timeout=60, exit_grace_period=5,
    poll_interval=0.5, steam_root=None,
    on_game_started=None
):
    """Monitor a Steam game and detect hotkey or tray exit requests."""
    import time

    if startup_timeout <= 0 or exit_grace_period < 0:
        raise ValueError("Invalid Steam monitoring timeout")

    if poll_interval <= 0:
        raise ValueError("Invalid Steam monitoring interval")

    if not resolve_steam_game_directory(app_id, steam_root):
        raise ValueError("Steam game installation not found")

    if exit_requested is None:
        exit_requested = threading.Event()

    listener = ManagedHotkeyListener(shortcut)
    deadline = time.monotonic() + startup_timeout
    game_started = False
    empty_since = None

    try:
        listener.start()

        logger.info(
            "Monitoring Steam game %s with shortcut %s",
            app_id, listener.shortcut
        )

        while True:
            processes = find_steam_game_processes(app_id, steam_root)
            now = time.monotonic()

            if processes:
                if not game_started:
                    pids = sorted(entry["pid"] for entry in processes)
                    logger.info(
                        "Steam game %s started: %s",
                        app_id, pids,
                    )
                    if on_game_started is not None:
                        # The managed callback independently verifies
                        # this PID before recording game startup.
                        on_game_started(pids[0])
                    game_started = True
                empty_since = None

            elif game_started:
                if empty_since is None:
                    empty_since = now

                if now - empty_since >= exit_grace_period:
                    logger.info(
                        "Steam game %s exited normally", app_id
                    )
                    return "process_exited"

            elif now >= deadline:
                logger.warning(
                    "Steam game %s startup timed out", app_id
                )
                return "startup_timeout"

            if listener.error is not None:
                raise listener.error

            if listener.detected.is_set():
                logger.info(
                    "Steam game %s exit hotkey detected", app_id
                )
                return "hotkey_detected"

            if exit_requested.is_set():
                logger.info(
                    "Steam game %s tray exit requested", app_id
                )
                return "hotkey_detected"

            if listener.stopped.is_set():
                raise RuntimeError(
                    "Steam hotkey listener stopped unexpectedly"
                )

            listener.detected.wait(timeout=poll_interval)

    finally:
        listener.stop()

def monitor_steam_game_processes(
    app_id, startup_timeout=60, exit_grace_period=5,
    poll_interval=0.5, steam_root=None
):
    """Observe a Steam game's process lifecycle without controlling it."""
    import time

    if startup_timeout <= 0 or exit_grace_period < 0:
        raise ValueError("Invalid Steam monitoring timeout")

    if poll_interval <= 0:
        raise ValueError("Invalid Steam monitoring interval")

    if not resolve_steam_game_directory(app_id, steam_root):
        raise ValueError("Steam game installation not found")

    deadline = time.monotonic() + startup_timeout
    game_started = False
    empty_since = None
    observed_pids = set()

    while True:
        processes = find_steam_game_processes(app_id, steam_root)
        current_pids = {entry["pid"] for entry in processes}
        now = time.monotonic()

        if current_pids:
            if not game_started:
                logger.info(
                    "Steam game %s detected: %s",
                    app_id, sorted(current_pids)
                )
                game_started = True

            new_pids = current_pids - observed_pids
            if new_pids:
                logger.info(
                    "Steam game %s new processes: %s",
                    app_id, sorted(new_pids)
                )

            observed_pids.update(current_pids)
            empty_since = None

        elif game_started:
            if empty_since is None:
                empty_since = now
                logger.info(
                    "Steam game %s has no running processes; "
                    "waiting for exit grace period",
                    app_id
                )

            if now - empty_since >= exit_grace_period:
                logger.info(
                    "Steam game %s exited; observed PIDs: %s",
                    app_id, sorted(observed_pids)
                )
                return "process_exited"

        elif now >= deadline:
            logger.warning(
                "Steam game %s was not detected before timeout",
                app_id
            )
            return "startup_timeout"

        time.sleep(poll_interval)

def find_steam_game_processes(app_id, steam_root=None):
    """Find running processes within an installed Steam game's directory."""
    game_directory = resolve_steam_game_directory(app_id, steam_root)

    if not game_directory:
        return []

    game_prefix = os.path.normcase(
        os.path.realpath(game_directory)
    ).rstrip("\\/") + os.sep

    matches = []

    for entry in list_windows_processes():
        if entry["pid"] <= 0:
            continue

        if entry["name"].lower() in (
            "crashreportclient.exe",
            "crashreporter.exe",
        ):
            continue

        try:
            executable = get_windows_process_executable(entry["pid"])
        except (OSError, ValueError):
            continue

        normalized = os.path.normcase(os.path.realpath(executable))

        if not normalized.startswith(game_prefix):
            continue

        matches.append({
            "pid": entry["pid"],
            "parent_pid": entry["parent_pid"],
            "name": entry["name"],
            "executable": executable,
        })

    return matches

def resolve_steam_game_directory(app_id, steam_root=None):
    """Resolve an installed Steam App ID across configured libraries."""
    import re

    app_id = str(app_id)

    if not re.fullmatch(r"[0-9]+", app_id):
        raise ValueError("Invalid Steam App ID")

    if steam_root is None:
        steam_root = os.path.join(
            os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
            "Steam"
        )

    libraries = [steam_root]
    library_config = os.path.join(
        steam_root, "steamapps", "libraryfolders.vdf"
    )

    if os.path.isfile(library_config):
        with open(
            library_config, "r", encoding="utf-8-sig"
        ) as handle:
            content = handle.read()

        for value in re.findall(
            r'"path"\s+"((?:\\.|[^"\\])*)"', content
        ):
            path = value.replace("\\\\", "\\")
            if path not in libraries:
                libraries.append(path)

    for library in libraries:
        manifest = os.path.join(
            library, "steamapps", "appmanifest_{}.acf".format(app_id)
        )

        if not os.path.isfile(manifest):
            continue

        with open(
            manifest, "r", encoding="utf-8-sig"
        ) as handle:
            content = handle.read()

        match = re.search(
            r'"installdir"\s+"([^"]+)"', content
        )

        if match is None:
            continue

        install_dir = match.group(1)

        if (
            not install_dir
            or os.path.isabs(install_dir)
            or "/" in install_dir
            or "\\" in install_dir
            or install_dir in (".", "..")
        ):
            raise ValueError("Unsafe Steam installation directory")

        game_path = os.path.join(
            library, "steamapps", "common", install_dir
        )

        if os.path.isdir(game_path):
            return os.path.abspath(game_path)

    return None

def list_windows_processes():
    """Return Windows process IDs, parent IDs, and executable names."""
    import ctypes
    from ctypes import wintypes

    if sys.platform != "win32":
        raise OSError("Windows process discovery requires Windows")

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    class PROCESSENTRY32W(ctypes.Structure):
        _fields_ = [
            ("dwSize", wintypes.DWORD),
            ("cntUsage", wintypes.DWORD),
            ("th32ProcessID", wintypes.DWORD),
            ("th32DefaultHeapID", ctypes.POINTER(ctypes.c_ulong)),
            ("th32ModuleID", wintypes.DWORD),
            ("cntThreads", wintypes.DWORD),
            ("th32ParentProcessID", wintypes.DWORD),
            ("pcPriClassBase", ctypes.c_long),
            ("dwFlags", wintypes.DWORD),
            ("szExeFile", wintypes.WCHAR * 260),
        ]

    kernel32.CreateToolhelp32Snapshot.argtypes = [
        wintypes.DWORD, wintypes.DWORD
    ]
    kernel32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    kernel32.Process32FirstW.argtypes = [
        wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W)
    ]
    kernel32.Process32FirstW.restype = wintypes.BOOL
    kernel32.Process32NextW.argtypes = [
        wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W)
    ]
    kernel32.Process32NextW.restype = wintypes.BOOL
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL

    snapshot = kernel32.CreateToolhelp32Snapshot(0x00000002, 0)
    if snapshot == ctypes.c_void_p(-1).value:
        raise ctypes.WinError(ctypes.get_last_error())

    processes = []

    try:
        entry = PROCESSENTRY32W()
        entry.dwSize = ctypes.sizeof(entry)

        if not kernel32.Process32FirstW(snapshot, ctypes.byref(entry)):
            error = ctypes.get_last_error()
            if error == 18:
                return processes
            raise ctypes.WinError(error)

        while True:
            processes.append({
                "pid": int(entry.th32ProcessID),
                "parent_pid": int(entry.th32ParentProcessID),
                "name": entry.szExeFile,
            })

            if not kernel32.Process32NextW(
                snapshot, ctypes.byref(entry)
            ):
                error = ctypes.get_last_error()
                if error != 18:
                    raise ctypes.WinError(error)
                break

        return processes

    finally:
        kernel32.CloseHandle(snapshot)

def is_kodi_already_running(kodi_executable):
    """Detect a running Kodi instance by its full executable path."""
    import ctypes
    from ctypes import wintypes

    if sys.platform != "win32":
        raise OSError("Kodi process discovery requires Windows")

    expected = os.path.normcase(os.path.abspath(kodi_executable))

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    kernel32.CreateToolhelp32Snapshot.argtypes = [
        wintypes.DWORD, wintypes.DWORD
    ]
    kernel32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE

    kernel32.Process32FirstW.argtypes = [
        wintypes.HANDLE, ctypes.c_void_p
    ]
    kernel32.Process32FirstW.restype = wintypes.BOOL

    kernel32.Process32NextW.argtypes = [
        wintypes.HANDLE, ctypes.c_void_p
    ]
    kernel32.Process32NextW.restype = wintypes.BOOL

    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL

    class PROCESSENTRY32W(ctypes.Structure):
        _fields_ = [
            ("dwSize", wintypes.DWORD),
            ("cntUsage", wintypes.DWORD),
            ("th32ProcessID", wintypes.DWORD),
            ("th32DefaultHeapID", ctypes.POINTER(ctypes.c_ulong)),
            ("th32ModuleID", wintypes.DWORD),
            ("cntThreads", wintypes.DWORD),
            ("th32ParentProcessID", wintypes.DWORD),
            ("pcPriClassBase", ctypes.c_long),
            ("dwFlags", wintypes.DWORD),
            ("szExeFile", wintypes.WCHAR * 260)
        ]

    TH32CS_SNAPPROCESS = 0x00000002
    snapshot = kernel32.CreateToolhelp32Snapshot(
        TH32CS_SNAPPROCESS, 0
    )

    invalid_handle = ctypes.c_void_p(-1).value

    if snapshot == invalid_handle:
        raise ctypes.WinError(ctypes.get_last_error())

    try:
        entry = PROCESSENTRY32W()
        entry.dwSize = ctypes.sizeof(entry)

        if not kernel32.Process32FirstW(
            snapshot, ctypes.byref(entry)
        ):
            raise ctypes.WinError(ctypes.get_last_error())

        while True:
            if entry.szExeFile.lower() == "kodi.exe":
                try:
                    actual = get_windows_process_executable(
                        entry.th32ProcessID
                    )

                    if os.path.normcase(os.path.abspath(actual)) == expected:
                        return True

                except OSError:
                    # An inaccessible Kodi process must not be
                    # mistaken for proof that no Kodi is running.
                    raise

            if not kernel32.Process32NextW(
                snapshot, ctypes.byref(entry)
            ):
                error = ctypes.get_last_error()
                if error != 18:
                    raise ctypes.WinError(error)
                break

        return False

    finally:
        kernel32.CloseHandle(snapshot)


def restart_managed_kodi(config, kodi_was_closed):
    """Restart Kodi only after confirmed managed shutdown."""
    if kodi_was_closed is not True:
        logger.info(
            "Kodi restart skipped: original Kodi shutdown not confirmed"
        )
        return False

    try:
        validated = validate_managed_kodi_config(config)
        executable = validated["kodi_executable"]

        # Refuse to create a duplicate Kodi instance, even if Kodi
        # was manually restarted under a different process ID.
        if is_kodi_already_running(executable):
            logger.warning(
                "Kodi restart skipped: another Kodi instance is running"
            )
            return False

        # The original PID must not still identify the original Kodi process.
        if verify_kodi_process(
            validated["kodi_pid"], executable
        ):
            logger.warning(
                "Kodi restart refused: original Kodi process still running"
            )
            return False

        logger.info("Restarting Kodi: %s", executable)

        subprocess.Popen(
            [executable],
            cwd=os.path.dirname(executable),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        return True

    except Exception:
        logger.exception("Managed Kodi restart failed")
        return False


# Windows structures for creating an emulator with its primary thread suspended.
# These are declarations only; no processes are started here.
import ctypes
from ctypes import wintypes


class ManagedStartupInfo(ctypes.Structure):
    _fields_ = [
        ("cb", wintypes.DWORD),
        ("lpReserved", wintypes.LPWSTR),
        ("lpDesktop", wintypes.LPWSTR),
        ("lpTitle", wintypes.LPWSTR),
        ("dwX", wintypes.DWORD),
        ("dwY", wintypes.DWORD),
        ("dwXSize", wintypes.DWORD),
        ("dwYSize", wintypes.DWORD),
        ("dwXCountChars", wintypes.DWORD),
        ("dwYCountChars", wintypes.DWORD),
        ("dwFillAttribute", wintypes.DWORD),
        ("dwFlags", wintypes.DWORD),
        ("wShowWindow", wintypes.WORD),
        ("cbReserved2", wintypes.WORD),
        ("lpReserved2", ctypes.POINTER(ctypes.c_byte)),
        ("hStdInput", wintypes.HANDLE),
        ("hStdOutput", wintypes.HANDLE),
        ("hStdError", wintypes.HANDLE),
    ]


class ManagedProcessInformation(ctypes.Structure):
    _fields_ = [
        ("hProcess", wintypes.HANDLE),
        ("hThread", wintypes.HANDLE),
        ("dwProcessId", wintypes.DWORD),
        ("dwThreadId", wintypes.DWORD),
    ]


def create_suspended_managed_process(
    application, arguments, working_directory=None
):
    """Create a Windows process suspended, retaining both native handles."""
    if sys.platform != "win32":
        raise OSError("Suspended process creation requires Windows")

    if not os.path.isfile(application):
        raise FileNotFoundError(application)

    if not isinstance(arguments, list) or any(
        not isinstance(value, str) for value in arguments
    ):
        raise ValueError("Managed process arguments must be strings")

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    create_process = kernel32.CreateProcessW
    create_process.argtypes = [
        wintypes.LPCWSTR,
        wintypes.LPWSTR,
        ctypes.c_void_p,
        ctypes.c_void_p,
        wintypes.BOOL,
        wintypes.DWORD,
        ctypes.c_void_p,
        wintypes.LPCWSTR,
        ctypes.POINTER(ManagedStartupInfo),
        ctypes.POINTER(ManagedProcessInformation),
    ]
    create_process.restype = wintypes.BOOL

    close_handle = kernel32.CloseHandle
    close_handle.argtypes = [wintypes.HANDLE]
    close_handle.restype = wintypes.BOOL

    startup = ManagedStartupInfo()
    startup.cb = ctypes.sizeof(startup)

    process_info = ManagedProcessInformation()

    # Match AKL's WindowsExecutor: normalize existing filesystem paths
    # without changing command switches, URLs, or other arguments.
    normalized_arguments = []
    for value in arguments:
        normalized = value.replace("/", "\\")
        if os.path.exists(normalized):
            normalized_arguments.append(normalized)
        else:
            normalized_arguments.append(value)

    command = subprocess.list2cmdline(
        [os.path.abspath(application)] + normalized_arguments
    )
    command_buffer = ctypes.create_unicode_buffer(command)

    if working_directory is None:
        working_directory = os.path.dirname(
            os.path.abspath(application)
        )
    else:
        if (
            not isinstance(working_directory, str)
            or not working_directory.strip()
        ):
            raise ValueError(
                "Managed process working directory must be a nonempty string"
            )

        if not os.path.isdir(working_directory):
            raise ValueError(
                "Managed process working directory does not exist: {}".format(
                    working_directory
                )
            )

        working_directory = os.path.abspath(working_directory)

    CREATE_SUSPENDED = 0x00000004

    # PyInstaller sets a DLL search directory for its bundled dependencies.
    # Prevent child emulators from inheriting that directory.
    set_dll_directory = kernel32.SetDllDirectoryW
    set_dll_directory.argtypes = [wintypes.LPCWSTR]
    set_dll_directory.restype = wintypes.BOOL

    bundled_directory = getattr(sys, "_MEIPASS", None)

    if bundled_directory:
        if not set_dll_directory(None):
            raise ctypes.WinError(ctypes.get_last_error())

    try:
        success = create_process(
            os.path.abspath(application),
            command_buffer,
            None,
            None,
            False,
            CREATE_SUSPENDED,
            None,
            working_directory,
            ctypes.byref(startup),
            ctypes.byref(process_info),
        )
        creation_error = ctypes.get_last_error() if not success else 0
    finally:
        if bundled_directory:
            if not set_dll_directory(bundled_directory):
                logger.error(
                    "Failed to restore PyInstaller DLL search directory: %s",
                    ctypes.WinError(ctypes.get_last_error())
                )

    if not success:
        raise ctypes.WinError(creation_error)

    if not process_info.hProcess or not process_info.hThread:
        terminate = kernel32.TerminateProcess
        terminate.argtypes = [wintypes.HANDLE, wintypes.UINT]
        terminate.restype = wintypes.BOOL

        wait = kernel32.WaitForSingleObject
        wait.argtypes = [wintypes.HANDLE, wintypes.DWORD]
        wait.restype = wintypes.DWORD

        cleanup_error = None

        try:
            if process_info.hProcess:
                if not terminate(process_info.hProcess, 1):
                    error = ctypes.get_last_error()
                    if wait(process_info.hProcess, 0) != 0:
                        cleanup_error = ctypes.WinError(error)

                if cleanup_error is None:
                    result = wait(process_info.hProcess, 5000)
                    if result != 0:
                        cleanup_error = RuntimeError(
                            "Incomplete process termination unconfirmed: {}".format(
                                result
                            )
                        )
            else:
                cleanup_error = RuntimeError(
                    "Cannot terminate incomplete process: no process handle"
                )
        finally:
            if process_info.hThread:
                close_handle(process_info.hThread)
                process_info.hThread = None
            if process_info.hProcess:
                close_handle(process_info.hProcess)
                process_info.hProcess = None

        if cleanup_error is not None:
            raise RuntimeError(
                "CreateProcessW returned incomplete handles; "
                "process termination could not be confirmed"
            ) from cleanup_error

        raise RuntimeError(
            "CreateProcessW returned incomplete handles; "
            "created process was terminated"
        )

    logger.info(
        "Managed process created suspended: PID %d",
        process_info.dwProcessId
    )

    return process_info


def cancel_suspended_managed_process(process_info, exit_code=1):
    """Terminate a suspended process and release its native handles."""
    if sys.platform != "win32":
        raise OSError("Suspended process cleanup requires Windows")

    if not isinstance(process_info, ManagedProcessInformation):
        raise TypeError("Expected ManagedProcessInformation")

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    terminate = kernel32.TerminateProcess
    terminate.argtypes = [wintypes.HANDLE, wintypes.UINT]
    terminate.restype = wintypes.BOOL

    wait = kernel32.WaitForSingleObject
    wait.argtypes = [wintypes.HANDLE, wintypes.DWORD]
    wait.restype = wintypes.DWORD

    close = kernel32.CloseHandle
    close.argtypes = [wintypes.HANDLE]
    close.restype = wintypes.BOOL

    WAIT_OBJECT_0 = 0
    WAIT_TIMEOUT = 0x102
    WAIT_FAILED = 0xFFFFFFFF

    process_handle = process_info.hProcess
    thread_handle = process_info.hThread

    try:
        if process_handle:
            if not terminate(process_handle, exit_code):
                error = ctypes.get_last_error()

                # A process that already exited does not need termination.
                if wait(process_handle, 0) != WAIT_OBJECT_0:
                    raise ctypes.WinError(error)

            result = wait(process_handle, 5000)

            if result == WAIT_TIMEOUT:
                raise TimeoutError(
                    "Suspended process did not terminate within 5 seconds"
                )

            if result == WAIT_FAILED:
                raise ctypes.WinError(ctypes.get_last_error())

            if result != WAIT_OBJECT_0:
                raise RuntimeError(
                    "Unexpected Windows process wait result: {}".format(
                        result
                    )
                )

            logger.info(
                "Suspended managed process cancelled: PID %d",
                process_info.dwProcessId
            )

    finally:
        if thread_handle:
            close(thread_handle)
            process_info.hThread = None

        if process_handle:
            close(process_handle)
            process_info.hProcess = None


def resume_suspended_managed_process(process_info):
    """Resume a suspended process and release its primary thread handle."""
    if sys.platform != "win32":
        raise OSError("Suspended process resumption requires Windows")

    if not isinstance(process_info, ManagedProcessInformation):
        raise TypeError("Expected ManagedProcessInformation")

    if not process_info.hProcess or not process_info.hThread:
        raise ValueError("Suspended process handles are missing")

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    resume = kernel32.ResumeThread
    resume.argtypes = [wintypes.HANDLE]
    resume.restype = wintypes.DWORD

    close = kernel32.CloseHandle
    close.argtypes = [wintypes.HANDLE]
    close.restype = wintypes.BOOL

    previous_count = resume(process_info.hThread)

    if previous_count == 0xFFFFFFFF:
        raise ctypes.WinError(ctypes.get_last_error())

    if previous_count != 1:
        raise RuntimeError(
            "Unexpected suspended thread count: {}".format(
                previous_count
            )
        )

    close(process_info.hThread)
    process_info.hThread = None

    logger.info(
        "Managed process resumed: PID %d",
        process_info.dwProcessId
    )

    return process_info.dwProcessId


class ManagedWindowsProcess:
    """Popen-compatible monitoring interface for a native process handle."""

    def __init__(self, process_info):
        if not isinstance(process_info, ManagedProcessInformation):
            raise TypeError("Expected ManagedProcessInformation")
        if not process_info.hProcess:
            raise ValueError("Native process handle is missing")

        self._info = process_info
        self.pid = int(process_info.dwProcessId)
        self.returncode = None

        self._kernel32 = ctypes.WinDLL(
            "kernel32", use_last_error=True
        )

        self._wait = self._kernel32.WaitForSingleObject
        self._wait.argtypes = [
            wintypes.HANDLE, wintypes.DWORD
        ]
        self._wait.restype = wintypes.DWORD

        self._exit_code = self._kernel32.GetExitCodeProcess
        self._exit_code.argtypes = [
            wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)
        ]
        self._exit_code.restype = wintypes.BOOL

    def _read_exit_code(self):
        code = wintypes.DWORD()
        if not self._exit_code(
            self._info.hProcess, ctypes.byref(code)
        ):
            raise ctypes.WinError(ctypes.get_last_error())

        # Windows reports unsigned DWORD exit codes.
        return int(code.value)

    def poll(self):
        if self.returncode is not None:
            return self.returncode

        result = self._wait(self._info.hProcess, 0)

        if result == 0x102:
            return None
        if result == 0xFFFFFFFF:
            raise ctypes.WinError(ctypes.get_last_error())
        if result != 0:
            raise RuntimeError(
                "Unexpected process wait result: {}".format(result)
            )

        self.returncode = self._read_exit_code()
        return self.returncode

    def wait(self, timeout=None):
        if self.returncode is not None:
            return self.returncode

        if timeout is None:
            milliseconds = 0xFFFFFFFF
        else:
            import math
            seconds = float(timeout)
            if not math.isfinite(seconds) or seconds < 0:
                raise ValueError("Invalid process wait timeout")
            milliseconds = min(
                math.ceil(seconds * 1000), 0xFFFFFFFE
            )

        result = self._wait(
            self._info.hProcess, milliseconds
        )

        if result == 0x102:
            raise subprocess.TimeoutExpired(
                "ManagedWindowsProcess", timeout
            )
        if result == 0xFFFFFFFF:
            raise ctypes.WinError(ctypes.get_last_error())
        if result != 0:
            raise RuntimeError(
                "Unexpected process wait result: {}".format(result)
            )

        self.returncode = self._read_exit_code()
        return self.returncode


def close_managed_process_handles(process_info):
    """Release native process handles without terminating the process."""
    if sys.platform != "win32":
        raise OSError("Native handle cleanup requires Windows")

    if not isinstance(process_info, ManagedProcessInformation):
        raise TypeError("Expected ManagedProcessInformation")

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    close = kernel32.CloseHandle
    close.argtypes = [wintypes.HANDLE]
    close.restype = wintypes.BOOL

    errors = []

    for attribute in ("hThread", "hProcess"):
        handle = getattr(process_info, attribute)

        if handle:
            if not close(handle):
                errors.append(
                    (attribute, ctypes.get_last_error())
                )
            else:
                setattr(process_info, attribute, None)

    if errors:
        raise OSError(
            "Failed to close managed process handles: {}".format(
                errors
            )
        )


def execute_managed_launch(config):
    """Run an emulator only after bookkeeping and verified Kodi shutdown."""
    validated = validate_managed_bookkeeping_config(config)
    application = config["application"]
    arguments = config["arguments"]
    shortcut = config["exit_shortcut"]

    process_info = None
    kodi_was_closed = False
    emulator_resumed = False
    tray = None
    exit_requested = threading.Event()

    try:
        process_info = create_suspended_managed_process(
            application,
            arguments,
            working_directory=config.get("working_directory")
        )

        logger.info(
            "Managed emulator created suspended: PID %d",
            process_info.dwProcessId
        )

        # AKL must receive this acknowledgment before committing stats.
        # The process exists but its primary thread has not run yet.
        started_path = write_managed_emulator_started(
            config, process_info.dwProcessId
        )
        logger.info(
            "Managed emulator creation acknowledged: %s",
            started_path
        )

        try:
            bookkeeping_ready = may_shutdown_kodi_after_bookkeeping(
                validated, timeout=30
            )
        except Exception:
            logger.exception("Managed bookkeeping failed")
            bookkeeping_ready = False

        if not bookkeeping_ready:
            logger.error(
                "Bookkeeping incomplete; cancelling suspended emulator"
            )
            return 1

        kodi_was_closed = safely_shutdown_verified_kodi(
            config, True, timeout=20
        )

        if not kodi_was_closed:
            logger.error(
                "Kodi shutdown unconfirmed; cancelling suspended emulator"
            )
            return 1

        resume_suspended_managed_process(process_info)
        emulator_resumed = True

        process = ManagedWindowsProcess(process_info)

        # The tray is optional; a failure must not disable the hotkey.
        try:
            helper_directory = os.path.dirname(
                os.path.abspath(sys.executable)
            )
            icon_path = os.path.join(
                helper_directory, "akl-revival-tray.ico"
            )
            tray = ManagedTrayIcon(exit_requested, icon_path)
            tray.start()
            logger.info("Managed tray icon started")
        except Exception:
            logger.exception(
                "Managed tray unavailable; continuing with hotkey"
            )
            if tray is not None:
                try:
                    tray.stop()
                except Exception:
                    logger.exception("Managed tray cleanup failed")
            tray = None

        result = run_managed_process(
            process, shortcut, exit_requested=exit_requested
        )

        logger.info(
            "Managed emulator monitoring completed: %s", result
        )

        if result == "process_exited":
            return 0

        return 1

    finally:
        if tray is not None:
            try:
                tray.stop()
                logger.info("Managed tray icon stopped")
            except Exception:
                logger.exception("Managed tray shutdown failed")

        emulator_stopped = process_info is None

        if process_info is not None and process_info.hProcess:
            try:
                native_process = ManagedWindowsProcess(process_info)

                if native_process.poll() is not None:
                    close_managed_process_handles(process_info)
                else:
                    cancel_suspended_managed_process(process_info)

                emulator_stopped = True

            except Exception:
                logger.exception(
                    "Managed emulator cleanup failed"
                )
                emulator_stopped = False

        elif process_info is not None:
            emulator_stopped = True

        if kodi_was_closed:
            if emulator_stopped:
                try:
                    restarted = restart_managed_kodi(config, True)
                    logger.info(
                        "Managed Kodi restart requested: %s", restarted
                    )
                except Exception:
                    logger.exception(
                        "Managed Kodi restart encountered an error"
                    )
            else:
                logger.error(
                    "Kodi restart withheld: emulator exit unconfirmed"
                )


def execute_managed_steam_launch(config):
    """Execute a verified managed Steam launch without affecting emulators."""
    validated = validate_managed_steam_config(config)

    if prepare_managed_steam_execution(validated) is not True:
        logger.error(
            "Managed Steam launch cancelled: Kodi shutdown unconfirmed"
        )
        return 1

    # The launch stage independently rechecks game readiness and Kodi state.
    # It also attempts Kodi recovery if the Steam request fails.
    try:
        start_managed_steam_after_kodi_shutdown(
            validated, kodi_shutdown_verified=True
        )
    except Exception:
        logger.exception("Managed Steam launch request failed")
        return 1

    # Steam uses the same optional tray implementation as managed emulators.
    # The tray and hotkey share an exit request without affecting Steam itself.
    exit_requested = threading.Event()
    tray = None

    try:
        try:
            helper_directory = os.path.dirname(
                os.path.abspath(sys.executable)
            )
            icon_path = os.path.join(
                helper_directory, "akl-revival-tray.ico"
            )
            tray = ManagedTrayIcon(exit_requested, icon_path)
            tray.start()
            logger.info("Managed Steam tray icon started")
        except Exception:
            logger.exception(
                "Managed Steam tray unavailable; continuing with hotkey"
            )
            if tray is not None:
                try:
                    tray.stop()
                except Exception:
                    logger.exception("Managed Steam tray cleanup failed")
            tray = None

        # Monitoring writes verified game-start evidence and independently
        # checks whether Kodi may safely be restarted.
        try:
            result = monitor_managed_steam_execution(
                validated, exit_requested=exit_requested
            )
        except Exception:
            logger.exception("Managed Steam monitoring or recovery failed")
            return 1

        if result in ("process_exited", "hotkey_closed"):
            return 0

        logger.warning(
            "Managed Steam launch did not complete normally: %s", result
        )
        return 1

    finally:
        if tray is not None:
            try:
                tray.stop()
                logger.info("Managed Steam tray icon stopped")
            except Exception:
                logger.exception("Managed Steam tray shutdown failed")

def main():
    if len(sys.argv) != 2:
        raise ValueError("Expected configuration file path")

    config_path = sys.argv[1]

    # Inspect only the launch type before selecting its dedicated validator.
    with open(config_path, "r", encoding="utf-8-sig") as handle:
        launch_header = json.load(handle)

    if not isinstance(launch_header, dict):
        raise ValueError("Managed-launch configuration must be an object")

    launch_type = launch_header.get("launch_type")

    if launch_type == "steam":
        config = load_managed_steam_configuration(config_path)

        log_directory = config["akl_addon_data_dir"]
        log_path = os.path.join(
            log_directory, "managed_steam_helper.log"
        )

        file_handler = logging.FileHandler(
            log_path, mode="a", encoding="utf-8"
        )
        file_handler.setLevel(logging.INFO)
        file_handler.setFormatter(
            logging.Formatter(
                "%(asctime)s %(levelname)s %(message)s"
            )
        )
        logger.addHandler(file_handler)

        logger.info(
            "=== Managed Steam launch started: launch_id=%s, pid=%s ===",
            config["launch_id"], os.getpid()
        )

        logger.info(
            "Managed Steam helper initialized: App ID %s",
            config["steam_app_id"]
        )

        return execute_managed_steam_launch(config)

    if launch_type not in (None, "emulator"):
        raise ValueError(
            "Unsupported managed launch type: {}".format(launch_type)
        )

    # Preserve the existing emulator execution path.
    config = load_configuration(config_path)

    logger.info("Managed Windows helper initialized")
    logger.info("Application: %s", config["application"])
    logger.info("Argument count: %d", len(config["arguments"]))

    return execute_managed_launch(config)


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s"
    )

    try:
        sys.exit(main())
    except Exception:
        logger.exception("Managed Windows helper failed")
        sys.exit(1)
