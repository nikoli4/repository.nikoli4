# 1.3.2
- Detect RPCS3 disc-folder sources by canonical `PS3_GAME/USRDIR/EBOOT.BIN` paths.
- In those sources, ignore unrelated `.BIN` files and accept only the canonical EBOOT.BIN launcher for each game.
- Preserve the 1.3.1 PS3 folder-name identity fix and all non-PS3 scanner behavior.

## 1.3.1
- Add narrowly scoped RPCS3 disc-folder naming support. Files matching `PS3_GAME/USRDIR/EBOOT.BIN` now use the folder immediately above `PS3_GAME` as the ROM name and identifier while preserving the original EBOOT.BIN launch path.

## Current
- Added direct file launcher
- Supporting new source types
- Updated to programs based file browser.

## Previous
- Added joystick suspend option.
- Minor bugfixes.