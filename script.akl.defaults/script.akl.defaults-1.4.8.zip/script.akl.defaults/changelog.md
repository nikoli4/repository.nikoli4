## 1.4.8

- Added Managed Windows Launcher integration to default launcher configuration.
- Improved launcher setup and configuration handling for managed launches.
- Updated AKL Revival release metadata.

## 1.4.7

- Improved scanning of extracted PlayStation 3 disc-folder games.
- Restricted PS3 BIN imports to valid PS3_GAME/USRDIR/EBOOT.BIN paths.
- Prevented unrelated BIN files from being imported as PS3 games.
- Improved platform-aware PS3 scanning.
- Made ROM extension matching case-insensitive.
- Passed the selected platform to the ROM scanner for more accurate game detection.

## 1.4.6

- Handled the update-settings command without displaying the add-on help dialog.
- Preserved the existing statically declared scraper capabilities.

## 1.4.5

- Fixed an error when changing the application executable for an existing launcher.
- Corrected file browser argument handling when selecting a launcher application.

## 1.4.4

- Renamed the updated icon and fanart assets so Kodi refreshes cached add-on artwork.

## 1.4.3

- Updated icon and fanart to the AKL Revival artwork.

## 1.4.2

- Updated the AKL module dependency to version 1.3.1 to match the scanner API used by the Setup Wizard.
- Updated the development dependency to script.module.akl 1.3.1.
- Maintenance release; no functional changes.

## 1.4.1

- Improved the Setup Wizard ROM scanner retry flow when no ROMs are found.
- Added an option to review the ROM path and file extensions and retry scanning during setup.
- Preserved the configured ROM path when reopening the scanner setup.
- Allowed Setup Wizard to continue cleanly when the user chooses to proceed without detected ROMs.
- Improved reporting of empty scan results back to Advanced Kodi Launcher during setup.

## 1.4.0

- Added Setup Wizard integration for Advanced Kodi Launcher Revival.

## 1.3.2

- Added support for RPCS3 extracted PlayStation 3 disc-folder games using `PS3_GAME/USRDIR/EBOOT.BIN`.
- PS3 disc-folder games now use the parent game-folder name instead of `EBOOT` as the ROM name and identifier.
- Added filtering of unrelated `.BIN` files when scanning PS3 disc-folder sources.

## Current
- Added direct file launcher
- Supporting new source types
- Updated to programs based file browser.

## Previous
- Added joystick suspend option.
- Minor bugfixes.