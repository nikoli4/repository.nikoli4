1.1.14
- Added Nintendo Switch -> ScreenScraper platform 225 mapping.

## 1.1.13
- Add narrowly scoped RPCS3 disc-folder support for Sony PlayStation 3 EBOOT.BIN entries.
- For paths ending in PS3_GAME/USRDIR/EBOOT.BIN, derive the scrape title from the folder above PS3_GAME and use ScreenScraper system-scoped romnom lookup instead of hashing EBOOT.BIN.
- Preserve the 1.1.12 Windows .lnk path and the original checksum-based path for all other ROMs unchanged.

## 1.1.6
- Diagnostic Windows .lnk global name search: omit systemeid and log returned game/system IDs.

## 1.1.5
- Correct ScreenScraper platform mapping for Microsoft Windows / PC Windows: 136 -> 138.

## 1.1.4\n- Fix Windows .lnk name-search parsing for current ScreenScraper jeuRecherche JSON response shapes.\n\n# Current
- Updated to new version of AKL
- Support for sources