# -*- coding: utf-8 -*-
"""Offline title matching helpers for ScreenScraper."""

import re
import unicodedata


def _normalize_title(title):
    """Normalize title text into comparable words."""
    title = unicodedata.normalize("NFKD", str(title or ""))
    title = "".join(
        char for char in title
        if not unicodedata.combining(char)
    )
    title = title.casefold()
    title = title.replace("&", " and ")
    title = re.sub(r"[^a-z0-9]+", " ", title)
    return title.split()


def _remove_internal_order_number(words):
    """Generate alternatives without a possible collection-order number."""
    alternatives = []

    for index, word in enumerate(words):
        if not word.isdigit():
            continue

        # A trailing number is likely a real sequel number.
        if index == len(words) - 1:
            continue

        # Require meaningful words on both sides.
        if index < 2 or len(words) - index - 1 < 2:
            continue

        alternative = words[:index] + words[index + 1:]
        alternatives.append(alternative)

    return alternatives


def match_title(requested_title, candidate_title):
    """Return True when titles match under conservative normalization."""
    requested = _normalize_title(requested_title)
    candidate = _normalize_title(candidate_title)

    if not requested or not candidate:
        return False

    if requested == candidate:
        return True

    # Numbers may identify genuine sequels or editions.
    # Never remove them without independent evidence.
    return False


def get_fallback_queries(title, max_queries=8):
    """Generate progressively shorter searches for an unresolved game title.

    Candidate titles returned by these queries must be validated separately
    against the original complete title before automatic selection.
    """
    words = re.sub(r"\s+", " ", str(title or "").replace("_", " ")).strip().split()

    # Avoid broadening short names or removing a trailing sequel number.
    if len(words) < 4 or words[-1].isdigit():
        return []

    queries = []
    seen = set()

    for length in range(len(words) - 1, 1, -1):
        prefix = words[:length]

        # Do not search for a prefix ending with a bare collection number.
        if prefix[-1].isdigit():
            continue

        query = " ".join(prefix)
        key = query.casefold()

        if key not in seen:
            queries.append(query)
            seen.add(key)

        if len(queries) >= max_queries:
            break

    return queries


def get_parent_title(rom_path):
    """Return a useful parent-folder title, excluding generic directories."""
    path = str(rom_path or "").replace("\\", "/").rstrip("/")

    if "/" not in path:
        return None

    parent = path.rsplit("/", 1)[0].rsplit("/", 1)[-1].strip()

    if not parent:
        return None

    normalized = " ".join(_normalize_title(parent))

    generic_folders = {
        "games", "game", "rom", "roms", "downloads", "download",
        "arcade", "emulators", "emulator", "isos", "iso",
        "disc", "discs", "disk", "disks", "images", "files",
        "nintendo gamecube", "nintendo wii", "nintendo 64",
        "playstation", "playstation 2", "playstation 3",
        "xbox", "xbox 360", "windows", "pc games",
    }

    if not normalized or normalized in generic_folders:
        return None

    return parent


def is_related_parent_title(rom_title, parent_title):
    """Require an unambiguous title match before trusting a parent folder.

    Parent folders can supply alternative search terms, but numeric
    differences must not silently change the game's identity.
    """
    rom_words = _normalize_title(rom_title)
    parent_words = _normalize_title(parent_title)

    if not rom_words or not parent_words:
        return False

    return rom_words == parent_words

def classify_parent_title(rom_title, parent_title):
    """Classify a parent-folder title without assuming numeric equivalence.

    'same' means normalized titles are identical.
    'alternative' means exactly one internal numeric token differs.
    'unrelated' means the folder is not a suitable search alternative.

    An alternative is a search lead, never proof of game identity.
    """
    rom_words = _normalize_title(rom_title)
    parent_words = _normalize_title(parent_title)

    if not rom_words or not parent_words:
        return "unrelated"

    generic_folders = {
        "games", "game", "rom", "roms", "downloads", "download",
        "arcade", "emulators", "emulator", "isos", "iso",
        "disc", "discs", "disk", "disks", "images", "files",
        "nintendo gamecube", "nintendo wii", "nintendo 64",
        "playstation", "playstation 2", "playstation 3",
        "xbox", "xbox 360", "windows", "pc games",
    }

    if " ".join(parent_words) in generic_folders:
        return "unrelated"

    if rom_words == parent_words:
        return "same"

    if len(rom_words) != len(parent_words) + 1:
        return "unrelated"

    for index, word in enumerate(rom_words):
        if not word.isdigit():
            continue

        # Require two preceding words and at least one following word.
        # A trailing sequel number must never be removed.
        if index < 2 or index >= len(rom_words) - 1:
            continue

        without_number = rom_words[:index] + rom_words[index + 1:]

        if without_number == parent_words:
            return "alternative"

    return "unrelated"

def choose_safe_search_title(rom_title, supplied_title, parent_title=None):
    """Choose a search title without silently trusting a parent folder.

    The supplied title is normally AKL's cleaned ROM filename, but may
    contain a manually entered correction. Parent-folder alternatives
    are search leads, not proof that a numbered title is equivalent.
    """
    supplied = str(supplied_title or "").strip()

    if not supplied:
        return None

    # AKL has already formatted the supplied search term. Preserve it,
    # including meaningful sequel numbers and explicit corrections.
    # Do not substitute parent_title without independent verification.
    return supplied
