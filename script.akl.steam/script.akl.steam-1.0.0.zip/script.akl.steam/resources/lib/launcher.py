#
# Advanced Kodi Launcher: Steam library launcher implementation
#
# Copyright (c) Chrisism <crizizz@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; version 2 of the License.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# --- Python standard library ---
from __future__ import unicode_literals
from __future__ import division

import logging

# --- AKL packages ---
from akl.utils import kodi
from akl.launchers import LauncherABC, ExecutorFactoryABC, ExecutionSettings

logger = logging.getLogger(__name__)


# -------------------------------------------------------------------------------------------------
# Launcher to use with a local Steam application and account.
# -------------------------------------------------------------------------------------------------
class SteamLauncher(LauncherABC):

    def __init__(self,
                 launcher_id: str,
                 rom_id: str,
                 webservice_host: str,
                 webservice_port: int,
                 executorFactory: ExecutorFactoryABC = None,
                 execution_settings: ExecutionSettings = None):
        self.logger = logging.getLogger(__name__)
        super(SteamLauncher, self).__init__(launcher_id, rom_id, webservice_host, webservice_port,
                                            executorFactory, execution_settings)
        
    # --------------------------------------------------------------------------------------------
    # Core methods
    # --------------------------------------------------------------------------------------------
    def get_name(self) -> str:
        return 'Steam Launcher'
     
    def get_launcher_addon_id(self) -> str:
        addon_id = kodi.get_addon_id()
        return addon_id

    # --------------------------------------------------------------------------------------------
    # Launcher build wizard methods
    # --------------------------------------------------------------------------------------------
    #
    # Creates a new launcher using a wizard of dialogs. Called by parent build() method.
    #
    def _builder_get_wizard(self, wizard):
        wizard = kodi.WizardDialog_Dummy(wizard, 'application', 'Steam')
        return wizard
    
    def _editor_get_wizard(self, wizard):
        wizard = kodi.WizardDialog_Dummy(wizard, 'application', 'Steam')
        return wizard
            
    def _build_post_wizard_hook(self):
        return True

    def _builder_get_edit_options(self):
        options = super(SteamLauncher, self)._builder_get_edit_options()
        if options is None:
            from collections import OrderedDict
            options = OrderedDict()

        managed = self.launcher_settings.get('managed_windows_launch', False)
        status = 'Enabled' if managed else 'Disabled'
        options[self._toggle_managed_windows_launch] = (
            'Managed Windows Launch ({})'.format(status)
        )

        if managed:
            shortcut = self.launcher_settings.get(
                'managed_exit_shortcut', 'Ctrl+Shift+X'
            )
            options[self._change_managed_exit_shortcut] = (
                'Exit / Return to Kodi Shortcut ({})'.format(shortcut)
            )

        return options

    def _toggle_managed_windows_launch(self):
        current = self.launcher_settings.get('managed_windows_launch', False)
        self.launcher_settings['managed_windows_launch'] = not current

    def _change_managed_exit_shortcut(self):
        current = self.launcher_settings.get(
            'managed_exit_shortcut', 'Ctrl+Shift+X'
        )
        shortcut = kodi.dialog_keyboard(
            'Exit / Return to Kodi Shortcut',
            text=current
        )

        if shortcut is None:
            return

        try:
            shortcut = self.validate_managed_exit_shortcut(shortcut)
        except ValueError as exc:
            kodi.notify_warn('Invalid exit shortcut: {}'.format(exc))
            return

        self.launcher_settings['managed_exit_shortcut'] = shortcut

    @staticmethod
    def validate_managed_exit_shortcut(shortcut):
        """Validate and normalize a managed exit shortcut."""
        if not isinstance(shortcut, str) or not shortcut.strip():
            raise ValueError('Exit shortcut must be a nonempty string')

        parts = [part.strip().upper() for part in shortcut.split('+')]
        aliases = {
            'CONTROL': 'CTRL',
            'CTL': 'CTRL',
            'MENU': 'ALT',
            'WIN': 'WINDOWS'
        }
        parts = [aliases.get(part, part) for part in parts]
        modifiers = {'CTRL', 'SHIFT', 'ALT', 'WINDOWS'}

        if any(not part for part in parts):
            raise ValueError('Exit shortcut contains an empty key')
        if len(parts) != len(set(parts)):
            raise ValueError('Exit shortcut contains duplicate keys')

        keys = [part for part in parts if part not in modifiers]
        if len(keys) != 1:
            raise ValueError('Exit shortcut must contain exactly one main key')

        key = keys[0]
        valid_key = (
            (len(key) == 1 and key in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789')
            or (
                key.startswith('F')
                and key[1:].isdigit()
                and 1 <= int(key[1:]) <= 24
            )
            or key in {'ESC', 'SPACE', 'ENTER', 'TAB'}
        )
        if not valid_key:
            raise ValueError('Unsupported exit shortcut key: {}'.format(key))

        ordered_modifiers = [
            modifier for modifier in ('CTRL', 'SHIFT', 'ALT', 'WINDOWS')
            if modifier in parts
        ]
        normalized = '+'.join(ordered_modifiers + [key])

        reserved = {
            'CTRL+ALT+DELETE', 'ALT+TAB', 'ALT+F4',
            'CTRL+SHIFT+ESC', 'WINDOWS+L', 'WINDOWS+D'
        }
        if normalized in reserved:
            raise ValueError(
                'Windows-reserved shortcut cannot be used: {}'.format(normalized)
            )

        return normalized
         
    # ---------------------------------------------------------------------------------------------
    # Execution methods
    # ---------------------------------------------------------------------------------------------
    def prepare_managed_steam_launch(
        self, launch_id, rom_id, addon_data_dir
    ):
        """Build and save a managed Steam configuration without launching."""
        config = self.build_managed_steam_configuration(
            launch_id, rom_id, addon_data_dir
        )
        return self.write_managed_steam_configuration(config)

    def start_managed_steam_helper(
        self, launch_id, rom_id, addon_data_dir
    ):
        """Prepare Steam configuration and start the existing managed helper."""
        import os
        import subprocess
        import xbmcvfs

        managed_addon_dir = xbmcvfs.translatePath(
            'special://home/addons/script.akl.managedlauncher/'
        )

        helper_exe = os.path.normpath(os.path.join(
            managed_addon_dir,
            'resources',
            'bin',
            'AKLManagedHelper',
            'AKLManagedHelper.exe'
        ))

        if not os.path.isfile(helper_exe):
            raise FileNotFoundError(
                'Managed Windows helper executable not found: {}'.format(
                    helper_exe
                )
            )

        config_path = self.prepare_managed_steam_launch(
            launch_id, rom_id, addon_data_dir
        )

        command = [helper_exe, config_path]

        creationflags = getattr(
            subprocess, 'CREATE_NEW_PROCESS_GROUP', 0
        )

        process = subprocess.Popen(
            command,
            cwd=os.path.dirname(helper_exe),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=creationflags
        )

        logger.info(
            'Managed Steam helper started: PID %s, launch_id=%s',
            process.pid,
            launch_id
        )

        return process.pid
    def write_managed_steam_configuration(self, config):
        """Write a validated, launch-specific Steam helper configuration."""
        import json
        import os
        import re

        if not isinstance(config, dict):
            raise ValueError('Steam configuration must be a dictionary')

        if config.get('launch_type') != 'steam':
            raise ValueError('Not a managed Steam configuration')

        launch_id = config.get('launch_id')
        if not isinstance(launch_id, str) or not re.fullmatch(
            r'[A-Za-z0-9_-]{1,128}', launch_id
        ):
            raise ValueError('Invalid managed Steam launch ID')

        app_id = config.get('steam_app_id')
        if not isinstance(app_id, str) or not re.fullmatch(
            r'[0-9]{1,20}', app_id
        ) or int(app_id) <= 0:
            raise ValueError('Invalid Steam App ID')

        arguments = config.get('steam_launch_arguments')
        if not isinstance(arguments, list) or not all(
            isinstance(arg, str) for arg in arguments
        ):
            raise ValueError('Invalid Steam launch arguments')

        data_dir = config.get('akl_addon_data_dir')
        if not isinstance(data_dir, str) or not os.path.isdir(data_dir):
            raise ValueError('Invalid AKL addon data directory')

        rom_id = config.get('rom_id')
        if not isinstance(rom_id, str) or not rom_id.strip():
            raise ValueError('Invalid Steam ROM ID')

        kodi_pid = config.get('kodi_pid')
        if type(kodi_pid) is not int or kodi_pid <= 0:
            raise ValueError('Invalid Kodi process ID')

        kodi_executable = config.get('kodi_executable')
        if not isinstance(kodi_executable, str) or (
            os.path.basename(kodi_executable).lower() != 'kodi.exe'
        ):
            raise ValueError('Invalid Kodi executable')

        shortcut = config.get('exit_shortcut')
        if not isinstance(shortcut, str) or not shortcut.strip():
            raise ValueError('Invalid Steam exit shortcut')

        destination = os.path.join(
            data_dir,
            'managed_steam_config_{}.json'.format(launch_id)
        )

        # Exclusive creation prevents accidental reuse or replacement.
        with open(destination, 'x', encoding='utf-8') as output:
            json.dump(config, output, indent=2, sort_keys=True)
            output.write('\n')

        return destination
    def build_managed_steam_configuration(
        self, launch_id, rom_id, addon_data_dir
    ):
        """Prepare a Steam-specific configuration without launching anything."""
        import ctypes
        import os
        import re
        import sys

        if sys.platform != 'win32':
            raise OSError('Managed Steam launch requires Windows')

        if not isinstance(launch_id, str) or not re.fullmatch(
            r'[A-Za-z0-9_-]{1,128}', launch_id
        ):
            raise ValueError('Invalid managed Steam launch ID')

        if not isinstance(rom_id, str) or not rom_id.strip():
            raise ValueError('Invalid managed Steam ROM ID')

        if not isinstance(addon_data_dir, str) or not os.path.isdir(
            addon_data_dir
        ):
            raise ValueError('Invalid AKL addon data directory')

        details = self.get_managed_steam_launch_details()

        kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
        get_module_filename = kernel32.GetModuleFileNameW
        get_module_filename.argtypes = [
            ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_uint
        ]
        get_module_filename.restype = ctypes.c_uint

        buffer = ctypes.create_unicode_buffer(32768)
        length = get_module_filename(None, buffer, len(buffer))

        if length == 0 or length >= len(buffer):
            raise OSError('Unable to identify running Kodi executable')

        kodi_executable = os.path.abspath(buffer.value)

        if os.path.basename(kodi_executable).lower() != 'kodi.exe':
            raise ValueError(
                'Managed Steam launch must originate from Kodi.exe'
            )

        return {
            'launch_type': 'steam',
            'steam_app_id': details['steam_app_id'],
            'steam_launch_arguments': details['steam_launch_arguments'],
            'exit_shortcut': self.launcher_settings.get(
                'managed_exit_shortcut', 'Ctrl+Shift+X'
            ),
            'launch_id': launch_id,
            'rom_id': rom_id,
            'akl_addon_data_dir': os.path.abspath(addon_data_dir),
            'kodi_pid': os.getpid(),
            'kodi_executable': kodi_executable,
        }
    def get_managed_steam_launch_details(self):
        """Resolve and validate a Steam App ID without launching the game."""
        import re

        arguments, keyword_arguments = self.get_arguments()

        if not isinstance(arguments, (list, tuple)) or not arguments:
            raise ValueError('Steam App ID was not resolved')

        app_id = arguments[0]

        if not isinstance(app_id, str):
            raise ValueError('Steam App ID must be a string')

        if not re.fullmatch(r'[0-9]{1,20}', app_id):
            raise ValueError('Invalid Steam App ID: {!r}'.format(app_id))

        if int(app_id) <= 0:
            raise ValueError('Steam App ID must be positive')

        if not all(isinstance(arg, str) for arg in arguments[1:]):
            raise ValueError('Steam launch arguments must be strings')

        if not isinstance(keyword_arguments, dict):
            raise ValueError('Invalid Steam launch keyword arguments')

        unsupported = set(keyword_arguments) - {'non_blocking'}
        if unsupported:
            raise ValueError(
                'Unsupported Steam launch keyword arguments: {}'.format(
                    sorted(unsupported)
                )
            )

        return {
            'steam_app_id': app_id,
            'steam_launch_arguments': list(arguments[1:]),
        }
    def get_application(self) -> str:
        return 'steam://rungameid/'
        
    def get_arguments(self) -> str:
        original_arguments = self.launcher_settings.get('args', '')
        self.launcher_settings['args'] = '{} {}'.format('$steamid$', original_arguments).strip()
        try:
            return super(SteamLauncher, self).get_arguments()
        finally:
            self.launcher_settings['args'] = original_arguments
    
