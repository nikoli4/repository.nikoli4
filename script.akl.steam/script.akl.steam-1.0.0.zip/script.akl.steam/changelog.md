## AKL Revival 1.0.0

- Rebranded the Steam integration as AKL Revival: Steam Plugin.
- Added Managed Windows Launcher integration for Steam games.
- Added managed launch configuration and exit shortcut support.
- Improved Steam scraper artwork and trailer handling.
- Added box-front artwork support.
- Improved Steam release-year parsing and category tags.
- Updated the minimum AKL Shared Module dependency to 1.4.2.
## Current
- Added support for new sources
- Added scraper

## Previous
First official release of this Steam plugin for AKL.