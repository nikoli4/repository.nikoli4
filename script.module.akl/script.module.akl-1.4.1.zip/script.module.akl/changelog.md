## 1.4.1

- Added Console as a supported system artwork type.
- Added support for the scraper update-settings command.

## 1.4.0

- Added Windows shortcut (.lnk) as a default ROM extension for the Windows platform.
- Improved scraper log privacy by preventing remote asset URLs and local asset paths from being written to debug logs.
- Enabled SSL certificate verification for scraper image downloads.

## 1.3.1

- Added support for suppressing the empty-ROM warning during Setup Wizard scans.
- Improved empty-ROM scan handling for the Advanced Kodi Launcher Setup Wizard.
- Added ZIP as a default ROM extension for supported Nintendo and Sega cartridge-based platforms.
- Added Wii U WUA support.
- Added default platform mappings for Sega 32X, Genesis, and Sega CD.

## Current
- Fix Application launcher not launching the app (fixed by: mallexxx)
- Cleanup log; case insensitive APPPATH, APPBASE
- Addon command utilities
- Windows LNK file execution fix
- Added extras fields to scraped data
- Use asset filenames that are allowed by system
- Generalized addon commands and parsing

## In previous releases
- Don't download assets of extension type *url*
- Updated media/artwork
- Fixed ok dialog issue with timer
- Added PEGI rating support
- Less logging by requests module, making logs more secure
- Added file dialogs support
- Fix for storing single ROM launcher settings